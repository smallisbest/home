"""Userspace L2 bridge with all impairments (Windows).

Windows has no widely-scriptable in-kernel L2 bridge for physical LAN cards
(Hyper-V VMSwitch requires the Hyper-V role and is designed for VMs, the
legacy "Network Bridge" feature has no scriptable API, and `netsh bridge`
was removed). WNE therefore implements the entire bridging + impairment
pipeline in userspace on top of Npcap (via scapy) — the same trick macOS
uses for pattern / every-N loss, extended here to cover *all* impairments
uniformly.

Per-bridge worker (one thread per ingress interface):

    ┌──────────── ingress iface ────────────┐
    │  scapy.sniff(promisc=True)           │
    │      │                                │
    │      ▼                                │
    │  direction filter                     │
    │      │                                │
    │      ▼                                │
    │  Loss decision (percent | every_n |   │
    │  pattern) — direction-aware counters  │
    │      │  drop → return                 │
    │      ▼                                │
    │  Bandwidth throttle (token bucket)    │
    │      │                                │
    │      ▼                                │
    │  Delay + Jitter (asyncio Queue with   │
    │  computed release time per packet)    │
    │      │                                │
    │      ▼                                │
    │  scapy.sendp(pkt, iface=<other>)      │
    └───────────────────────────────────────┘

State file format (`C:\\ProgramData\\wne\\run\\bridges.json`):

    {
      "bridges": [
        { "id": "br0",
          "members": ["Ethernet 1", "Ethernet 2"],
          "direction": "both",
          "impairments": {
            "delay_ms": 5, "jitter_ms": 1, "bandwidth_kbps": 10000,
            "loss": {"mode": "pattern", "pattern": "0011", "n": 0,
                     "direction": "both"}
          }
        }
      ]
    }
"""
from __future__ import annotations

import heapq
import json
import logging
import os
import queue
import random
import signal
import sys
import threading
import time
from pathlib import Path

try:
    from scapy.all import conf as _scapy_conf, sniff, sendp
except ImportError:
    print("ERROR: scapy is not installed. `pip install scapy` and install Npcap.", file=sys.stderr)
    sys.exit(1)

_scapy_conf.verb = 0
log = logging.getLogger("wne.bridge")


# ------------------------------------------------- loss primitives --

class LossCounter:
    """Per-ingress drop decision. Mirrors nfq_worker / pcap_worker exactly."""

    def __init__(self, mode: str, n: int = 0, pattern: str = "", percent: float | None = None):
        self.mode = mode
        self.n = max(0, int(n))
        self.pattern = pattern or ""
        self.percent = percent
        self.i = 0
        self.lock = threading.Lock()

    def should_drop(self) -> bool:
        with self.lock:
            if self.mode == "percent" and self.percent:
                return random.random() * 100.0 < self.percent
            if self.mode == "every_n" and self.n > 0:
                self.i = (self.i + 1) % self.n
                return self.i == 0
            if self.mode == "pattern" and self.pattern:
                idx = self.i % len(self.pattern)
                self.i += 1
                return self.pattern[idx] == "1"
            return False


# ------------------------------------------------- bandwidth throttle --

class TokenBucket:
    """Simple token bucket for BW throttling. bytes/second granularity."""

    def __init__(self, rate_kbps: int, burst_bytes: int | None = None):
        self.rate_bps = max(0, rate_kbps) * 1000 / 8.0     # kbits/s → bytes/s
        self.capacity = burst_bytes if burst_bytes is not None else max(1500, int(self.rate_bps * 0.05))
        self.tokens = float(self.capacity)
        self.updated = time.monotonic()
        self.lock = threading.Lock()

    def consume(self, size: int) -> float:
        """Return the delay (seconds) to wait before this packet may be sent."""
        if self.rate_bps <= 0:
            return 0.0
        with self.lock:
            now = time.monotonic()
            elapsed = now - self.updated
            self.updated = now
            self.tokens = min(self.capacity, self.tokens + elapsed * self.rate_bps)
            if size <= self.tokens:
                self.tokens -= size
                return 0.0
            missing = size - self.tokens
            wait = missing / self.rate_bps
            self.tokens = 0
            return wait


# ------------------------------------------------- delay queue --

class DelayQueue:
    """Min-heap keyed on scheduled release time — pops packets when due."""

    def __init__(self):
        self._heap: list[tuple[float, int, bytes, str]] = []
        self._cv = threading.Condition()
        self._seq = 0
        self._stop = False

    def push(self, release_at: float, payload: bytes, out_if: str) -> None:
        with self._cv:
            self._seq += 1
            heapq.heappush(self._heap, (release_at, self._seq, payload, out_if))
            self._cv.notify()

    def stop(self) -> None:
        with self._cv:
            self._stop = True
            self._cv.notify_all()

    def run_pump(self) -> None:
        """Blocking loop: pull ready packets and sendp them."""
        while True:
            with self._cv:
                while not self._heap and not self._stop:
                    self._cv.wait()
                if self._stop and not self._heap:
                    return
                release_at, _seq, payload, out_if = self._heap[0]
                now = time.monotonic()
                if release_at > now:
                    self._cv.wait(timeout=release_at - now)
                    continue
                heapq.heappop(self._heap)
            try:
                sendp(payload, iface=out_if, verbose=False)
            except Exception as e:
                log.debug("sendp failed on %s: %s", out_if, e)


# ------------------------------------------------- per-bridge orchestration --

class BridgeWorker:
    def __init__(self, spec: dict):
        self.id = spec["id"]
        self.members: list[str] = list(spec["members"])
        self.direction = spec.get("direction", "both")
        imp = spec.get("impairments") or {}
        self.bypass = bool(imp.get("bypass"))
        self.delay_ms = float(imp.get("delay_ms") or 0)
        self.jitter_ms = float(imp.get("jitter_ms") or 0)
        self.bandwidth_kbps = int(imp.get("bandwidth_kbps") or 0)
        loss = imp.get("loss") or {}
        self.loss_mode = loss.get("mode") if not self.bypass else None
        self.loss_direction = loss.get("direction", "both") if loss else "both"
        self.loss_kwargs = dict(
            n=loss.get("n") or 0,
            pattern=loss.get("pattern") or "",
            percent=loss.get("percent"),
        )
        # per-ingress-iface loss counter (None if no loss on that side).
        self.counters: dict[str, LossCounter | None] = self._build_counters()
        # single shared BW bucket per direction? For simplicity: one per bridge.
        self.bucket = TokenBucket(self.bandwidth_kbps) if self.bandwidth_kbps else None
        self.delayq = DelayQueue()
        self._threads: list[threading.Thread] = []

    def _build_counters(self) -> dict[str, LossCounter | None]:
        out: dict[str, LossCounter | None] = {}
        for idx, iface in enumerate(self.members):
            include = (
                self.loss_mode is not None
                and self.loss_direction != "none"
                and (
                    self.loss_direction == "both"
                    or (self.loss_direction == "l2r" and idx == 0)
                    or (self.loss_direction == "r2l" and idx != 0)
                )
            )
            out[iface] = LossCounter(self.loss_mode, **self.loss_kwargs) if include else None
        return out

    def start(self) -> None:
        if len(self.members) < 2:
            log.warning("bridge %s: <2 members, nothing to forward", self.id)
            return

        # delay pump thread
        t = threading.Thread(target=self.delayq.run_pump, daemon=True,
                             name=f"delay-{self.id}")
        t.start()
        self._threads.append(t)

        # one sniff thread per ingress iface
        for ingress in self.members:
            others = tuple(m for m in self.members if m != ingress)
            counter = self.counters.get(ingress)

            def handle(pkt, ingress=ingress, others=others, counter=counter):
                if counter and counter.should_drop():
                    return
                raw = bytes(pkt)
                # BW: reserve tokens synchronously (adds "wait" to schedule)
                bw_delay = self.bucket.consume(len(raw)) if self.bucket else 0.0
                # Base delay + jitter (normal-ish → uniform for simplicity)
                d = self.delay_ms / 1000.0
                if self.jitter_ms > 0:
                    d += random.uniform(-self.jitter_ms, self.jitter_ms) / 1000.0
                    if d < 0:
                        d = 0
                release_at = time.monotonic() + bw_delay + d
                for out_if in others:
                    self.delayq.push(release_at, raw, out_if)

            def run_sniffer(ingress=ingress, handler=handle):
                log.info("[%s] sniff %s", self.id, ingress)
                try:
                    sniff(iface=ingress, prn=handler, store=False, promisc=True)
                except Exception:
                    log.exception("sniff failed on %s", ingress)

            t = threading.Thread(target=run_sniffer, daemon=True,
                                 name=f"sniff-{self.id}-{ingress}")
            t.start()
            self._threads.append(t)

        log.info("bridge %s up (members=%s, dir=%s, bypass=%s, loss=%s)",
                 self.id, ",".join(self.members), self.direction, self.bypass, self.loss_mode)

    def stop(self) -> None:
        self.delayq.stop()


def main() -> None:
    logging.basicConfig(
        level=os.environ.get("WNE_LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )
    state_file = Path(os.environ.get(
        "WNE_BRIDGE_STATE",
        r"C:\ProgramData\wne\run\bridges.json",
    ))
    if not state_file.exists():
        log.info("no state file (%s); nothing to do", state_file)
        return
    state = json.loads(state_file.read_text())
    bridges = state.get("bridges") or []
    if not bridges:
        log.info("no bridges; exiting")
        return

    workers = []
    for spec in bridges:
        w = BridgeWorker(spec)
        w.start()
        workers.append(w)

    stop = threading.Event()

    def _term(signum, frame):
        log.info("signal %d received", signum)
        stop.set()

    signal.signal(signal.SIGTERM, _term)
    signal.signal(signal.SIGINT, _term)
    stop.wait()
    for w in workers:
        w.stop()


if __name__ == "__main__":
    main()
