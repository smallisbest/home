"""Config schema and persistence (Windows).

Schema is identical to the Linux / macOS builds; only the on-disk path,
default hostapd behavior (none), and jitter-support notes differ.
"""
from __future__ import annotations

from pathlib import Path
from typing import Literal, Optional

import bcrypt
from pydantic import BaseModel, Field, field_validator


CONFIG_PATH = Path(r"C:\ProgramData\wne\config.json")


class LossConfig(BaseModel):
    mode: Literal["percent", "every_n", "pattern"]
    percent: Optional[float] = None
    n: Optional[int] = None
    pattern: Optional[str] = None
    direction: Literal["both", "l2r", "r2l", "none"] = "both"

    @field_validator("pattern")
    @classmethod
    def _validate_pattern(cls, v):
        if v is None:
            return v
        if not v or any(c not in "01" for c in v):
            raise ValueError("pattern must be a non-empty string of 0/1")
        return v


class Impairments(BaseModel):
    bypass: bool = True
    loss: Optional[LossConfig] = None
    delay_ms: Optional[float] = None
    jitter_ms: Optional[float] = None
    bandwidth_kbps: Optional[int] = None


class Node(BaseModel):
    id: str
    iface: str
    type: Literal["LAN", "WiFi"] = "LAN"
    description: str = ""
    up: bool = True

    @field_validator("type", mode="before")
    @classmethod
    def _normalize_type(cls, v):
        if isinstance(v, str):
            low = v.lower()
            if low == "lan":  return "LAN"
            if low == "wifi": return "WiFi"
        return v


class Bridge(BaseModel):
    id: str
    members: list[str] = Field(default_factory=list, max_length=2)
    direction: Literal["l2r", "r2l", "both"] = "both"
    enabled: bool = True
    impairments: Impairments = Field(default_factory=Impairments)


class WifiConfig(BaseModel):
    enabled: bool = False
    ssid: str = "WNE-AP"
    channel: int = 6
    hw_mode: Literal["a", "b", "g", "n", "ac"] = "g"
    wpa_passphrase: str = "changeme123"
    country_code: str = "KR"


class User(BaseModel):
    username: str
    password_hash: str


def _default_users() -> list[User]:
    return [
        User(
            username="admin",
            password_hash=bcrypt.hashpw(b"admin", bcrypt.gensalt()).decode(),
        )
    ]


class WebConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8080
    users: list[User] = Field(default_factory=_default_users)


class Config(BaseModel):
    version: int = 1
    web: WebConfig = Field(default_factory=WebConfig)
    wifi: WifiConfig = Field(default_factory=WifiConfig)
    allowed_interfaces: list[str] = Field(default_factory=list)
    nodes: list[Node] = Field(default_factory=list)
    bridges: list[Bridge] = Field(default_factory=list)


def load_config(path: Path = CONFIG_PATH) -> Config:
    if not path.exists():
        cfg = Config(nodes=_seed_nodes_from_system())
        save_config(cfg, path)
        return cfg
    return Config.model_validate_json(path.read_text())


def _seed_nodes_from_system(allowed: list[str] | None = None) -> list[Node]:
    """One node per Windows NetAdapter (excludes loopback / hidden virtuals)."""
    try:
        from . import winnet
        links = winnet.list_links()
    except Exception:
        return []
    allow_set = set(allowed or [])
    seeded: list[Node] = []
    for l in links:
        ifname = l.get("ifname", "")
        if not ifname:
            continue
        if allow_set and ifname not in allow_set:
            continue
        kind = (l.get("kind") or "").lower()
        nodetype: Literal["LAN", "WiFi"] = "WiFi" if kind in ("wireless", "wifi", "wlan") else "LAN"
        seeded.append(Node(id=_safe_id(ifname), iface=ifname, type=nodetype))
    return seeded


def _safe_id(ifname: str) -> str:
    """Windows adapter names often contain spaces / parens — squash them."""
    out = []
    for c in ifname:
        if c.isalnum():
            out.append(c)
        elif c in "-_":
            out.append(c)
        elif c == " ":
            out.append("_")
    s = "".join(out) or "n"
    return s[:32]


def save_config(cfg: Config, path: Path = CONFIG_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(cfg.model_dump_json(indent=2))
    tmp.replace(path)
