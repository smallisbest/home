"""Windows controller.

Everything (L2 forwarding + delay/jitter/BW/loss) is handled by a single
userspace worker (`bridge_worker.py`). The controller only:

  1. Applies per-node link state (Enable-NetAdapter / Disable-NetAdapter)
  2. Writes the bridges JSON state file the worker reads on start
  3. Spawns / respawns the worker process
  4. Configures + starts the netsh hosted network for Wi-Fi (if enabled)
"""
from __future__ import annotations

import json
import logging
import os
import signal
import subprocess
import sys
from pathlib import Path

from . import winnet as nl
from .config import Config

log = logging.getLogger("wne.ctrl")

RUN_DIR = Path(r"C:\ProgramData\wne\run")
BRIDGE_STATE_PATH = RUN_DIR / "bridges.json"
BRIDGE_PID_PATH = RUN_DIR / "bridge.pid"


class Controller:
    def __init__(self):
        self.touched_ifaces: set[str] = set()
        self.wifi_active: bool = False
        RUN_DIR.mkdir(parents=True, exist_ok=True)

    # ---------------- apply / teardown ----------------

    def apply(self, cfg: Config) -> None:
        log.info("applying configuration (Windows)")

        # 1) Stop any previously-running worker + Wi-Fi hosted network.
        self._stop_bridge_worker()
        if self.wifi_active:
            try:
                nl.hosted_network_stop()
            except Exception:
                log.exception("hosted_network_stop failed")
            self.wifi_active = False

        # 2) Per-node link up/down state.
        for node in cfg.nodes:
            if not nl.link_exists(node.iface):
                continue
            try:
                (nl.link_up if node.up else nl.link_down)(node.iface)
            except Exception:
                log.exception("link toggle failed: %s", node.iface)

        # 3) Assemble bridge specs (only enabled + both-members-up bridges).
        node_by_id = {n.id: n for n in cfg.nodes}
        specs: list[dict] = []
        for br in cfg.bridges:
            if not br.enabled:
                log.info("bridge %s disabled — skipped", br.id)
                continue
            members: list[str] = []
            for mid in br.members:
                node = node_by_id.get(mid)
                if node is None:
                    log.warning("bridge %s references unknown node %s", br.id, mid)
                    continue
                if not node.up:
                    log.info("bridge %s: skip down node %s", br.id, node.id)
                    continue
                if not nl.link_exists(node.iface):
                    log.warning("bridge %s: iface %s missing", br.id, node.iface)
                    continue
                members.append(node.iface)
                self.touched_ifaces.add(node.iface)
            if len(members) != 2:
                log.warning("bridge %s: needs 2 members, got %d", br.id, len(members))
                continue
            imp = br.impairments
            specs.append({
                "id": br.id,
                "members": members,
                "direction": br.direction,
                "impairments": {
                    "bypass": imp.bypass,
                    "delay_ms": imp.delay_ms,
                    "jitter_ms": imp.jitter_ms,
                    "bandwidth_kbps": imp.bandwidth_kbps,
                    "loss": {
                        "mode": imp.loss.mode,
                        "n": imp.loss.n,
                        "pattern": imp.loss.pattern,
                        "percent": imp.loss.percent,
                        "direction": imp.loss.direction,
                    } if imp.loss else None,
                },
            })

        # 4) Persist state + (re)start the userspace bridge worker.
        BRIDGE_STATE_PATH.write_text(json.dumps({"bridges": specs}, indent=2))
        if specs:
            self._start_bridge_worker()

        # 5) Wi-Fi hosted network (netsh wlan hostednetwork).
        if cfg.wifi.enabled:
            try:
                nl.hosted_network_configure(cfg.wifi.ssid, cfg.wifi.wpa_passphrase)
                nl.hosted_network_start()
                self.wifi_active = True
                log.info("hosted network started (ssid=%s)", cfg.wifi.ssid)
            except Exception:
                log.exception("hosted network setup failed — check `netsh wlan show drivers`")

        log.info("apply done: %d userspace bridges", len(specs))

    def teardown(self) -> None:
        log.info("tearing down")
        self._stop_bridge_worker()
        if self.wifi_active:
            try:
                nl.hosted_network_stop()
            except Exception:
                pass
            self.wifi_active = False

    # ---------------- worker subprocess ----------------

    def _start_bridge_worker(self) -> None:
        self._stop_bridge_worker()
        env = {**os.environ, "WNE_BRIDGE_STATE": str(BRIDGE_STATE_PATH)}
        p = subprocess.Popen(
            [sys.executable, "-m", "wne.bridge_worker"],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
        )
        BRIDGE_PID_PATH.write_text(str(p.pid))
        log.info("bridge worker started pid=%d", p.pid)

    def _stop_bridge_worker(self) -> None:
        if not BRIDGE_PID_PATH.exists():
            return
        try:
            pid = int(BRIDGE_PID_PATH.read_text().strip())
            # Windows has no SIGTERM to arbitrary processes from Python's stdlib
            # in a portable way — use taskkill.
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/F", "/T"],
                check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            log.info("bridge worker stopped pid=%d", pid)
        except (ValueError, OSError):
            pass
        BRIDGE_PID_PATH.unlink(missing_ok=True)

    @property
    def applied_bridges(self) -> set[str]:
        """Compat property so status output can list currently-live bridge ids."""
        try:
            state = json.loads(BRIDGE_STATE_PATH.read_text())
            return {b["id"] for b in state.get("bridges", [])}
        except Exception:
            return set()
