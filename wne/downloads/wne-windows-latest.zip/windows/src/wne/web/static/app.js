"use strict";
/* WNE Web UI — circular node graph with drag-to-connect bridges.
 *
 * Mock mode: when loaded via file:// OR with ?mock=1, the JS replaces the
 * /api/* fetches with an in-memory backend persisted in localStorage.
 * This lets you preview and play with the UI without running the daemon. */

const SVG_NS = "http://www.w3.org/2000/svg";
const VIEW = { w: 800, h: 600 };
const CENTER = { x: 400, y: 300 };
const NODE_R = 38;
const HUB_R = 14;

/* ---------------- Mock backend (JS-side) ---------------- */

const MOCK_KEY = "wne-mock-config-v1";

const MOCK_INTERFACES = [
  { ifname: "eth0",    address: "aa:bb:cc:00:00:01", operstate: "UP",   kind: "ethernet" },
  { ifname: "eth1",    address: "aa:bb:cc:00:00:02", operstate: "UP",   kind: "ethernet" },
  { ifname: "eth2",    address: "aa:bb:cc:00:00:03", operstate: "DOWN", kind: "ethernet" },
  { ifname: "eth3",    address: "aa:bb:cc:00:00:04", operstate: "DOWN", kind: "ethernet" },
  { ifname: "enp3s0",  address: "aa:bb:cc:00:00:05", operstate: "UP",   kind: null       },
  { ifname: "enxa0b1", address: "aa:bb:cc:00:00:06", operstate: "DOWN", kind: null       },
  { ifname: "wlan0",   address: "aa:bb:cc:00:00:10", operstate: "UP",   kind: "wlan"     },
  { ifname: "docker0", address: "02:42:de:ad:be:ef", operstate: "UP",   kind: "bridge"   },
];

function mockDefaultConfig() {
  return {
    version: 1,
    web: { host: "127.0.0.1", port: 8080, users: [{ username: "admin", password_hash: "(mock)" }] },
    wifi: { enabled: false, ssid: "WNE-AP", channel: 6, hw_mode: "g", wpa_passphrase: "changeme123", country_code: "KR" },
    allowed_interfaces: [],
    nodes: seedNodesFromInterfaces(MOCK_INTERFACES, []),
    bridges: [],
  };
}

/* Pretty-print an interface name into something the user can recognize.
   Returns a short Korean/English label like "Wi-Fi", "USB Ethernet", "Docker bridge".
   Returns "" if nothing better than the ifname itself can be derived. */
function friendlyIfaceLabel(iface) {
  if (!iface) return "";
  const n = String(iface.ifname || "");
  const k = String(iface.kind || "").toLowerCase();
  if (!n) return "";

  if (n === "lo" || n === "lo0" || k === "loopback") return "Loopback";

  // Wi-Fi by kind OR name (covers wlan0, wlp3s0, wlx*, etc.)
  if (k === "wlan" || k === "wireless" || /^(wlan|wlp|wlx|wl[0-9])/.test(n)) return "Wi-Fi";
  if (/^wwan/.test(n))                                                       return "Cellular WWAN";

  // macOS-specific virtuals
  if (/^awdl/.test(n))     return "AirDrop / Wi-Fi Aware";
  if (/^llw/.test(n))      return "Low-latency Wi-Fi";
  if (/^utun/.test(n))     return "VPN tunnel";
  if (/^anpi/.test(n))     return "Apple Network Processor";
  if (/^ap[0-9]+$/.test(n)) return "AP mode (Internet Sharing)";
  if (n === "gif0" || n === "stf0") return "IPv6 tunnel";

  // Bridges
  if (/^br-[0-9a-f]{8,}/.test(n))           return "Docker network";
  if (n === "docker0")                       return "Docker bridge";
  if (/^virbr/.test(n))                      return "libvirt bridge";
  if (/^vmnet/.test(n))                      return "VMware";
  if (/^lxdbr/.test(n))                      return "LXD bridge";
  if (/^(br|bridge)[0-9]+$/.test(n) || k === "bridge") return "Bridge";

  // Linux predictable Ethernet names
  if (/^eth([0-9]+)$/.test(n))   return `Ethernet ${n.match(/^eth([0-9]+)$/)[1]}`;
  if (/^enp[0-9]+s/.test(n))     return "PCI Ethernet (내장)";
  if (/^eno[0-9]+/.test(n))      return "온보드 Ethernet";
  if (/^ens[0-9]+/.test(n))      return "Hot-plug Ethernet";
  if (/^enx[0-9a-f]+/i.test(n))  return "USB Ethernet";

  // macOS en* (en0 is usually built-in Wi-Fi or built-in Ethernet; ambiguous)
  if (n === "en0") return "내장 인터페이스 (Wi-Fi 또는 Ethernet)";
  if (/^en[0-9]+$/.test(n)) {
    const num = n.slice(2);
    return `보조 Ethernet/USB (en${num})`;
  }

  // Tunnels / virtual
  if (/^tun/.test(n) || k === "tun")  return "VPN tunnel";
  if (/^tap/.test(n))                 return "TAP";
  if (/^veth/.test(n) || k === "veth") return "Virtual pair (veth)";
  if (/^bond/.test(n))                return "Bonding";
  if (/^team/.test(n))                return "Team aggregation";
  if (/^vlan/.test(n) || k === "vlan") return "VLAN";
  if (/^ip6tnl/.test(n))              return "IPv6 tunnel";
  if (/^sit/.test(n))                 return "IPv6-in-IPv4 tunnel";

  // Last-resort fallback by kind only
  if (k === "ethernet") return "Ethernet";

  return "";
}

function seedNodesFromInterfaces(ifaces, allowed) {
  const allowSet = new Set(allowed || []);
  return (ifaces || [])
    .filter(x => x.ifname && x.ifname !== "lo" && x.ifname !== "lo0")
    .filter(x => allowSet.size === 0 || allowSet.has(x.ifname))
    .map(x => ({
      id: x.ifname,
      iface: x.ifname,
      type: (x.kind === "wireless" || /^wl/.test(x.ifname)) ? "WiFi" : "LAN",
      description: "",
      up: (x.operstate || "").toUpperCase() !== "DOWN",
    }));
}

function mockLoad() {
  try {
    const raw = localStorage.getItem(MOCK_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  const cfg = mockDefaultConfig();
  mockSave(cfg);
  return cfg;
}
function mockSave(cfg) {
  try { localStorage.setItem(MOCK_KEY, JSON.stringify(cfg)); } catch (e) {}
}

function mockApi(path, body) {
  if (path === "/api/config" && body === undefined)
    return { ok: true, config: mockLoad(), mock: true };
  if (path === "/api/config" && body !== undefined) {
    mockSave(body);
    return { ok: true, mock: true };
  }
  if (path === "/api/interfaces")
    return { ok: true, interfaces: MOCK_INTERFACES, mock: true };
  if (path === "/api/status")
    return { ok: true, bridges: mockLoad().bridges.map(b => b.id), config_path: "(mock — localStorage)", mock: true };
  if (path === "/api/reload")
    return { ok: true, mock: true };
  if (path === "/api/password")
    return { ok: true, mock: true, note: "password change is a no-op in mock mode" };
  return { ok: false, error: "unknown api path", mock: true };
}

/* Detect mock mode: file://, or ?mock=1, or if first /api call fails. */
const params = new URLSearchParams(window.location.search);
let IS_MOCK = window.location.protocol === "file:" || params.get("mock") === "1";

/* ---------------- Main app ---------------- */

const WNE = {
  cfg: null,
  interfaces: [],
  selection: null,   // {type: 'node'|'bridge', id}
  drag: null,        // {fromId, fromX, fromY, x, y, moved}

  async init() {
    await this.load();
    this.bindGlobal();
  },

  bindGlobal() {
    const svg = document.getElementById("canvas");
    svg.addEventListener("mousemove", e => this.onMove(e));
    window.addEventListener("mouseup", e => this.onUp(e));
    svg.addEventListener("click", e => {
      if (e.target === svg || e.target.tagName === "svg" || e.target.id === "empty-hint") {
        this.clearSelection();
      }
    });
    window.addEventListener("resize", () => this.render());
    document.addEventListener("keydown", e => {
      if (e.key === "Escape") {
        if (this.drag) { this.drag = null; this.renderDragLine(); }
        else this.clearSelection();
      }
    });
  },

  /* ---------- API ---------- */

  async api(path, body) {
    if (IS_MOCK) return mockApi(path, body);
    const opts = body !== undefined
      ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }
      : {};
    try {
      const r = await fetch(path, opts);
      if (r.status === 401) { location.reload(); return null; }
      const j = await r.json();
      return j;
    } catch (e) {
      // Network error — fall back to mock so the UI still works.
      console.warn("api fetch failed, switching to MOCK:", e);
      IS_MOCK = true;
      return mockApi(path, body);
    }
  },

  async load() {
    this.setStatus("로딩…", "busy");
    const c = await this.api("/api/config");
    if (!c || !c.ok) { this.setStatus("error: " + (c && c.error || "?"), "err"); return; }
    this.cfg = c.config;
    this.cfg.nodes              = this.cfg.nodes   || [];
    this.cfg.bridges            = this.cfg.bridges || [];
    this.cfg.wifi               = this.cfg.wifi    || {};
    this.cfg.allowed_interfaces = this.cfg.allowed_interfaces || [];
    this.cfg.nodes.forEach(n => {
      if (n.type === "lan")  n.type = "LAN";
      else if (n.type === "wifi") n.type = "WiFi";
    });
    const ifs = await this.api("/api/interfaces");
    this.interfaces = (ifs && ifs.interfaces) || [];
    document.getElementById("mock-badge").classList.toggle("hidden", !(IS_MOCK || c.mock));
    this.render();
    this.setStatus(IS_MOCK ? "MOCK" : "OK", "ok");
  },

  setStatus(msg, kind) {
    const el = document.getElementById("status");
    el.textContent = msg;
    el.className = "status " + (kind || "ok");
  },

  /* ---------- Geometry ---------- */

  nodePosition(idx, total) {
    if (total <= 0) return { x: CENTER.x, y: CENTER.y };
    const angle = 2 * Math.PI * idx / total - Math.PI / 2;
    const r = Math.min(VIEW.w, VIEW.h) * 0.36;
    return { x: CENTER.x + r * Math.cos(angle), y: CENTER.y + r * Math.sin(angle) };
  },

  nodePositionOf(id) {
    const idx = this.cfg.nodes.findIndex(n => n.id === id);
    if (idx < 0) return null;
    return this.nodePosition(idx, this.cfg.nodes.length);
  },

  bridgeHubPosition(br) {
    const positions = br.members.map(id => this.nodePositionOf(id)).filter(p => p);
    if (positions.length === 0) return CENTER;
    const x = positions.reduce((s, p) => s + p.x, 0) / positions.length;
    const y = positions.reduce((s, p) => s + p.y, 0) / positions.length;
    // For 2-member bridges the hub sits exactly on the line midpoint — nudge slightly
    // outward to avoid overlapping the line.
    return { x, y };
  },

  /* ---------- Render ---------- */

  render() {
    this.renderEmpty();
    this.renderBridges();
    this.renderNodes();
    this.renderDetail();
  },

  renderEmpty() {
    document.getElementById("empty-hint").classList.toggle("hidden", this.cfg.nodes.length > 0);
  },

  renderNodes() {
    const layer = document.getElementById("nodes-layer");
    layer.innerHTML = "";
    this.cfg.nodes.forEach((n, idx) => {
      const pos = this.nodePosition(idx, this.cfg.nodes.length);
      const selected = this.selection && this.selection.type === "node" && this.selection.id === n.id;
      const isDown = n.up === false;
      const g = svgEl("g", {
        class: "node-group" + (selected ? " selected" : "") + (isDown ? " down" : ""),
        transform: `translate(${pos.x},${pos.y})`,
        "data-node-id": n.id,
      });
      g.appendChild(svgEl("circle", { class: "node-ring", r: NODE_R + 8 }));
      g.appendChild(svgEl("circle", { class: "node-circle" + (n.type === "WiFi" ? " wifi" : "") + (isDown ? " down" : ""), r: NODE_R }));
      g.appendChild(svgEl("text", { class: "node-label", y: -2 }, n.id));
      g.appendChild(svgEl("text", { class: "node-iface", y: 14 }, n.iface || "(no iface)"));
      if (n.type === "WiFi") g.appendChild(svgEl("text", { class: "node-iface", y: -22 }, "📶"));

      g.addEventListener("mousedown", e => {
        if (e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();
        this.startDrag(n.id, pos);
        g.classList.add("dragging");
      });
      g.addEventListener("click", e => {
        e.stopPropagation();
        if (!this.dragMoved) this.selectNode(n.id);
      });

      layer.appendChild(g);
    });
  },

  renderBridges() {
    const layer = document.getElementById("bridges-layer");
    layer.innerHTML = "";
    this.cfg.bridges.forEach(br => {
      if (!br.members || br.members.length < 2) return;
      const Lpos = this.nodePositionOf(br.members[0]);
      const Rpos = this.nodePositionOf(br.members[1]);
      if (!Lpos || !Rpos) return;
      const hub = { x: (Lpos.x + Rpos.x) / 2, y: (Lpos.y + Rpos.y) / 2 };

      const imp = br.impairments || {};
      const disabled = br.enabled === false;
      const dir = br.direction || (imp.loss && imp.loss.direction && imp.loss.direction !== "none" ? imp.loss.direction : "both");
      const lossActive = imp.loss && imp.loss.mode && (imp.loss.direction || "both") !== "none";
      const hasOtherImp = imp.delay_ms || imp.jitter_ms || imp.bandwidth_kbps;
      const cls = disabled ? "bridge-line disabled"
                 : imp.bypass ? "bridge-line bypass"
                 : lossActive ? "bridge-line loss"
                 : (hasOtherImp ? "bridge-line impaired" : "bridge-line");
      const selected = this.selection && this.selection.type === "bridge" && this.selection.id === br.id;
      const g = svgEl("g", {
        class: "bridge-group" + (selected ? " selected" : "") + (disabled ? " disabled" : ""),
        "data-bridge-id": br.id,
      });

      // Single L→R line carrying direction arrows.
      // Shorten endpoints so arrowheads don't overlap the node circles.
      const dx = Rpos.x - Lpos.x, dy = Rpos.y - Lpos.y;
      const len = Math.hypot(dx, dy) || 1;
      const ux = dx / len, uy = dy / len;
      const pad = NODE_R + 6;
      const x1 = Lpos.x + ux * pad, y1 = Lpos.y + uy * pad;
      const x2 = Rpos.x - ux * pad, y2 = Rpos.y - uy * pad;

      const line = svgEl("line", { class: cls, x1, y1, x2, y2 });
      if (dir === "l2r" || dir === "both") line.setAttribute("marker-end",   "url(#arrow-end)");
      if (dir === "r2l" || dir === "both") line.setAttribute("marker-start", "url(#arrow-start)");
      line.addEventListener("click", e => { e.stopPropagation(); this.selectBridge(br.id); });
      g.appendChild(line);

      const hubCls = "bridge-hub" + (disabled ? " disabled" : imp.bypass ? "" : (lossActive ? " loss" : (hasOtherImp ? " impaired" : "")));
      const hubEl = svgEl("circle", { class: hubCls, cx: hub.x, cy: hub.y, r: HUB_R });
      hubEl.addEventListener("click", e => { e.stopPropagation(); this.selectBridge(br.id); });
      g.appendChild(hubEl);
      g.appendChild(svgEl("text", { class: "bridge-label", x: hub.x, y: hub.y + 3 }, br.id));

      layer.appendChild(g);
    });
  },

  /* ---------- Drag-to-connect ---------- */

  startDrag(nodeId, pos) {
    this.drag = { fromId: nodeId, fromX: pos.x, fromY: pos.y, x: pos.x, y: pos.y };
    this.dragMoved = false;
    this.renderDragLine();
  },

  onMove(e) {
    if (!this.drag) return;
    const pt = this.svgPoint(e);
    this.drag.x = pt.x; this.drag.y = pt.y;
    const dx = pt.x - this.drag.fromX, dy = pt.y - this.drag.fromY;
    if (dx * dx + dy * dy > 36) this.dragMoved = true;
    this.renderDragLine();

    // Highlight potential drop target
    document.querySelectorAll(".node-group .node-circle").forEach(c => c.classList.remove("drag-target"));
    const target = this.nodeAtPoint(e);
    if (target && target.dataset.nodeId !== this.drag.fromId) {
      target.querySelector(".node-circle").classList.add("drag-target");
    }
  },

  onUp(e) {
    if (!this.drag) return;
    const target = this.nodeAtPoint(e);
    if (target) {
      const toId = target.dataset.nodeId;
      if (toId && toId !== this.drag.fromId && this.dragMoved) {
        this.createBridge(this.drag.fromId, toId);
      }
    }
    this.drag = null;
    document.querySelectorAll(".node-group.dragging").forEach(g => g.classList.remove("dragging"));
    document.querySelectorAll(".node-circle.drag-target").forEach(c => c.classList.remove("drag-target"));
    this.renderDragLine();
    setTimeout(() => { this.dragMoved = false; }, 10);
  },

  renderDragLine() {
    const layer = document.getElementById("drag-layer");
    layer.innerHTML = "";
    if (!this.drag) return;
    layer.appendChild(svgEl("line", {
      class: "drag-line",
      x1: this.drag.fromX, y1: this.drag.fromY,
      x2: this.drag.x,     y2: this.drag.y,
    }));
  },

  svgPoint(e) {
    const svg = document.getElementById("canvas");
    const pt = svg.createSVGPoint();
    pt.x = e.clientX; pt.y = e.clientY;
    return pt.matrixTransform(svg.getScreenCTM().inverse());
  },

  nodeAtPoint(e) {
    let el = document.elementFromPoint(e.clientX, e.clientY);
    while (el && el !== document.body) {
      if (el.classList && el.classList.contains("node-group")) return el;
      el = el.parentNode;
    }
    return null;
  },

  /* ---------- Selection ---------- */

  selectNode(id)   { this.selection = { type: "node",   id }; this.render(); },
  selectBridge(id) { this.selection = { type: "bridge", id }; this.render(); },
  clearSelection() { this.selection = null; this.render(); },

  /* ---------- Detail panel ---------- */

  renderDetail() {
    const panel = document.getElementById("detail");
    const body  = document.getElementById("detail-body");
    if (!this.selection) { panel.classList.add("hidden"); return; }
    panel.classList.remove("hidden");
    body.innerHTML = this.selection.type === "node"
      ? this.nodeDetailHTML()
      : this.bridgeDetailHTML();
    this.bindDetail();
  },

  nodeDetailHTML() {
    const n = this.cfg.nodes.find(x => x.id === this.selection.id);
    if (!n) return "<p>(deleted)</p>";
    if (n.up === undefined) n.up = true;
    // Filter by allow-list, but always keep the currently selected iface visible.
    const allowed = new Set(this.allowedInterfaces().map(x => x.ifname));
    const ifOpts = this.interfaces
      .filter(x => allowed.size === 0 || allowed.has(x.ifname) || x.ifname === n.iface)
      .map(x => {
        const blocked = allowed.size > 0 && !allowed.has(x.ifname);
        const hint    = friendlyIfaceLabel(x);
        return `<option value="${esc(x.ifname)}" ${x.ifname === n.iface ? "selected" : ""}>${esc(x.ifname)}${hint ? ` — ${esc(hint)}` : ""}${blocked ? " ⚠ 비허용" : ""}</option>`;
      }).join("");
    const ifaceBlocked = n.iface && !this.isAllowed(n.iface);
    const currentIface = this.interfaces.find(x => x.ifname === n.iface);
    const currentHint  = friendlyIfaceLabel(currentIface);
    return `
      <h3>Node <code>${esc(n.id)}</code></h3>
      <label>ID</label>
      <input data-k="id" value="${esc(n.id)}">
      <label>Interface</label>
      <select data-k="iface">
        <option value="">(선택)</option>
        ${ifOpts}
      </select>
      ${currentHint ? `<p class="hint">${esc(currentHint)}</p>` : ""}
      ${ifaceBlocked ? `<p class="hint" style="color:#d33">⚠ 현재 인터페이스가 허용 목록에 없습니다.</p>` : ""}
      <label>Type</label>
      <select data-k="type">
        <option value="LAN"  ${n.type === "LAN"  ? "selected" : ""}>LAN</option>
        <option value="WiFi" ${n.type === "WiFi" ? "selected" : ""}>WiFi</option>
      </select>
      <label>설명</label>
      <input data-k="description" value="${esc(n.description || "")}">

      <div class="toggle-row">
        <div class="toggle-label">
          <b>Link state</b>
          <div class="hint">Down 으로 두면 <code>ip link set ${esc(n.iface || "?")} down</code> 으로 내려가고, 어떤 브리지에도 포함되지 않습니다.</div>
        </div>
        <label class="switch">
          <input type="checkbox" data-up ${n.up ? "checked" : ""}>
          <span class="switch-track"><span class="switch-thumb"></span></span>
          <span class="switch-text">${n.up ? "UP" : "DOWN"}</span>
        </label>
      </div>

      <p class="hint">이 노드가 멤버로 포함된 브리지: ${
        (this.cfg.bridges.filter(b => b.members.includes(n.id)).map(b => `<code>${esc(b.id)}</code>`).join(", ")) || "(없음)"
      }</p>
      <div class="actions">
        <button class="danger" onclick="WNE.removeSelectedNode()">노드 삭제</button>
      </div>
    `;
  },

  bridgeDetailHTML() {
    const b = this.cfg.bridges.find(x => x.id === this.selection.id);
    if (!b) return "<p>(deleted)</p>";
    b.impairments = b.impairments || { bypass: true };
    const imp = b.impairments;
    imp.loss = imp.loss || null;
    if (b.enabled === undefined) b.enabled = true;

    // Migrate legacy loss.direction → bridge.direction on first view.
    if (b.direction === undefined) {
      const legacy = imp.loss && imp.loss.direction;
      b.direction = (legacy === "l2r" || legacy === "r2l") ? legacy : "both";
    }

    const lossMode = (imp.loss && imp.loss.mode) || "";
    const lid = b.members[0], rid = b.members[1];

    const optsFor = (selectedId) => this.cfg.nodes.map(n =>
      `<option value="${esc(n.id)}" ${n.id === selectedId ? "selected" : ""}>${esc(n.id)}${n.type === "WiFi" ? " 📶" : ""}${n.iface ? ` — ${esc(n.iface)}` : ""}</option>`
    ).join("");

    let lossEditor = "";
    if (lossMode === "percent")
      lossEditor = `<label>퍼센트 (%)</label><input data-loss="percent" type="number" step="0.1" min="0" max="100" value="${imp.loss.percent ?? ""}">`;
    else if (lossMode === "every_n")
      lossEditor = `<label>N (N개당 1개 드롭)</label><input data-loss="n" type="number" min="1" value="${imp.loss.n ?? ""}">`;
    else if (lossMode === "pattern")
      lossEditor = `<label>패턴 (0=통과, 1=드롭, 순환)</label><input data-loss="pattern" value="${esc(imp.loss.pattern || "")}" placeholder="예: 0001100000111" style="font-family: ui-monospace, monospace">`;

    return `
      <h3>Bridge <code>${esc(b.id)}</code></h3>
      <label>ID</label>
      <input data-k="id" value="${esc(b.id)}">

      <label>Members <span class="hint">(L = Start, R = Term)</span></label>
      <div class="lr-pair">
        <div>
          <span class="lr-tag">L</span>
          <select data-pos="L">${optsFor(lid)}</select>
        </div>
        <div>
          <span class="lr-tag">R</span>
          <select data-pos="R">${optsFor(rid)}</select>
        </div>
      </div>

      <label>Direction</label>
      <select data-direction>
        <option value="l2r"  ${b.direction === "l2r"  ? "selected" : ""}>L → R</option>
        <option value="r2l"  ${b.direction === "r2l"  ? "selected" : ""}>L ← R</option>
        <option value="both" ${b.direction === "both" ? "selected" : ""}>L ↔ R</option>
      </select>

      <div class="toggle-row">
        <div class="toggle-label">
          <b>Bridge state</b>
          <div class="hint">Disabled 면 브리지 / tc / nftables 가 만들어지지 않습니다.</div>
        </div>
        <label class="switch">
          <input type="checkbox" data-enabled ${b.enabled ? "checked" : ""}>
          <span class="switch-track"><span class="switch-thumb"></span></span>
          <span class="switch-text">${b.enabled ? "ENABLED" : "DISABLED"}</span>
        </label>
      </div>

      <div class="bypass-toggle">
        <input type="checkbox" data-bypass id="bypass-cb" ${imp.bypass ? "checked" : ""}>
        <label for="bypass-cb" style="margin:0"><b>Bypass</b> — 임페어먼트 모두 비활성</label>
      </div>

      <fieldset ${imp.bypass ? "disabled" : ""}>
        <legend>Impairments</legend>
        <div class="row">
          <div>
            <label>Delay (ms)</label>
            <input data-imp="delay_ms" type="number" min="0" step="0.1" value="${imp.delay_ms ?? ""}">
          </div>
          <div>
            <label>Jitter (ms)</label>
            <input data-imp="jitter_ms" type="number" min="0" step="0.1" value="${imp.jitter_ms ?? ""}">
          </div>
        </div>
        <label>Bandwidth (kbps)</label>
        <input data-imp="bandwidth_kbps" type="number" min="0" value="${imp.bandwidth_kbps ?? ""}">

        <label style="margin-top:14px">Packet Loss</label>
        <select data-loss-mode>
          <option value=""        ${lossMode === ""        ? "selected" : ""}>없음</option>
          <option value="percent" ${lossMode === "percent" ? "selected" : ""}>퍼센트</option>
          <option value="every_n" ${lossMode === "every_n" ? "selected" : ""}>N개당 1개</option>
          <option value="pattern" ${lossMode === "pattern" ? "selected" : ""}>비트 패턴</option>
        </select>
        ${lossEditor}
      </fieldset>

      <div class="actions">
        <button class="danger" onclick="WNE.removeSelectedBridge()">브리지 삭제</button>
      </div>
    `;
  },

  bindDetail() {
    const panel = document.getElementById("detail-body");
    const target = this.selection.type === "node"
      ? this.cfg.nodes.find(x => x.id === this.selection.id)
      : this.cfg.bridges.find(x => x.id === this.selection.id);
    if (!target) return;

    panel.querySelectorAll("[data-k]").forEach(el => {
      el.onchange = () => {
        const k = el.dataset.k;
        const oldId = target.id;
        target[k] = el.value;
        if (k === "id") {
          if (this.selection.type === "node") {
            this.cfg.bridges.forEach(b => { b.members = b.members.map(m => m === oldId ? el.value : m); });
          }
          this.selection.id = el.value;
        }
        this.render();
      };
    });

    if (this.selection.type === "node") {
      const up = panel.querySelector("[data-up]");
      if (up) up.onchange = () => { target.up = up.checked; this.render(); };
      return;
    }
    if (this.selection.type !== "bridge") return;
    const b = target;
    const enabled = panel.querySelector("[data-enabled]");
    if (enabled) enabled.onchange = () => { b.enabled = enabled.checked; this.render(); };

    panel.querySelectorAll("[data-pos]").forEach(el => {
      el.onchange = () => {
        const pos = el.dataset.pos;                  // "L" or "R"
        const myIdx    = pos === "L" ? 0 : 1;
        const otherIdx = pos === "L" ? 1 : 0;
        const newId    = el.value;
        // If the picked node is already on the other side, swap them.
        if (b.members[otherIdx] === newId) b.members[otherIdx] = b.members[myIdx];
        b.members[myIdx] = newId;
        this.render();
      };
    });
    const dirSel = panel.querySelector("[data-direction]");
    if (dirSel) dirSel.onchange = () => {
      b.direction = dirSel.value;
      // Mirror to legacy loss.direction so the existing backend honors it.
      if (b.impairments.loss) b.impairments.loss.direction = dirSel.value;
      this.render();
    };
    const bypass = panel.querySelector("[data-bypass]");
    if (bypass) bypass.onchange = () => { b.impairments.bypass = bypass.checked; this.render(); };

    panel.querySelectorAll("[data-imp]").forEach(el => {
      el.onchange = () => {
        const k = el.dataset.imp;
        b.impairments[k] = el.value === "" ? null : Number(el.value);
        this.render();
      };
    });

    const lossMode = panel.querySelector("[data-loss-mode]");
    if (lossMode) lossMode.onchange = () => {
      const m = lossMode.value;
      if (!m) b.impairments.loss = null;
      else {
        b.impairments.loss = { mode: m, percent: null, n: null, pattern: null, direction: b.direction || "both" };
      }
      this.render();
    };
    ["percent", "n", "pattern"].forEach(k => {
      const el = panel.querySelector(`[data-loss="${k}"]`);
      if (!el) return;
      el.onchange = () => {
        if (!b.impairments.loss) return;
        if (k === "pattern") {
          if (!/^[01]+$/.test(el.value)) {
            alert("패턴은 0/1만 (예: 0001100000111)");
            el.value = b.impairments.loss.pattern || "";
            return;
          }
          b.impairments.loss.pattern = el.value;
        } else if (k === "percent") {
          b.impairments.loss.percent = el.value === "" ? null : parseFloat(el.value);
        } else if (k === "n") {
          b.impairments.loss.n = el.value === "" ? null : parseInt(el.value);
        }
        this.render();
      };
    });
  },

  /* ---------- CRUD ---------- */

  addNode() {
    const used = new Set(this.cfg.nodes.map(n => n.iface));
    const pool = this.allowedInterfaces();
    const candidate = pool.find(x => !used.has(x.ifname) && x.ifname !== "lo" && x.ifname !== "lo0");
    if (!candidate && pool.length === 0 && (this.cfg.allowed_interfaces || []).length > 0) {
      alert("허용된 인터페이스가 없습니다. 헤더의 [🔌 인터페이스] 에서 사용할 인터페이스를 골라주세요.");
      return;
    }
    let id = "";
    for (let i = 1; i < 1000; i++) {
      id = "n" + (this.cfg.nodes.length + i);
      if (!this.cfg.nodes.some(n => n.id === id)) break;
    }
    this.cfg.nodes.push({
      id,
      iface: candidate ? candidate.ifname : "",
      type: candidate && (candidate.kind === "wireless" || /^wl/.test(candidate.ifname || "")) ? "WiFi" : "LAN",
      description: "",
    });
    this.render();
    this.selectNode(id);
  },

  removeSelectedNode() {
    if (!this.selection || this.selection.type !== "node") return;
    const id = this.selection.id;
    if (!confirm(`노드 ${id} 를 삭제할까요? 이 노드가 포함된 브리지에서도 자동으로 제외됩니다.`)) return;
    this.cfg.nodes = this.cfg.nodes.filter(n => n.id !== id);
    // A bridge requires exactly 2 members — drop it if either side disappears.
    this.cfg.bridges = this.cfg.bridges.filter(b => !b.members.includes(id));
    this.clearSelection();
  },

  createBridge(fromId, toId) {
    const existing = this.cfg.bridges.find(b => b.members.includes(fromId) && b.members.includes(toId));
    if (existing) { this.selectBridge(existing.id); return; }
    let bid = "";
    for (let i = 0; i < 1000; i++) {
      bid = "br" + (this.cfg.bridges.length + i);
      if (!this.cfg.bridges.some(b => b.id === bid)) break;
    }
    this.cfg.bridges.push({
      id: bid,
      members: [fromId, toId],
      direction: "both",
      impairments: { bypass: true, loss: null, delay_ms: null, jitter_ms: null, bandwidth_kbps: null },
    });
    this.render();
    this.selectBridge(bid);
  },

  removeSelectedBridge() {
    if (!this.selection || this.selection.type !== "bridge") return;
    const id = this.selection.id;
    if (!confirm(`브리지 ${id} 를 삭제할까요?`)) return;
    this.cfg.bridges = this.cfg.bridges.filter(b => b.id !== id);
    this.clearSelection();
  },

  /* ---------- Save / reload ---------- */

  async save() {
    this.setStatus("적용 중…", "busy");
    const r = await this.api("/api/config", this.cfg);
    if (!r) return;
    if (r.ok) { this.setStatus(IS_MOCK ? "MOCK 저장됨" : "적용 완료", "ok"); }
    else      { this.setStatus("실패: " + r.error, "err"); }
  },

  async reload() {
    const wasEmpty = this.cfg && (this.cfg.nodes || []).length === 0 && (this.cfg.bridges || []).length === 0;
    await this.load();
    if ((this.cfg.nodes || []).length === 0 && (this.cfg.bridges || []).length === 0) {
      this.cfg.nodes = seedNodesFromInterfaces(this.interfaces, this.cfg.allowed_interfaces);
      this.render();
      this.setStatus(wasEmpty ? "초기값으로 시드함" : (IS_MOCK ? "MOCK" : "OK"), "ok");
    }
  },

  /* Apply the configured allow-list filter to a list of interface objects. */
  allowedInterfaces() {
    const allow = this.cfg && this.cfg.allowed_interfaces;
    if (!allow || allow.length === 0) return this.interfaces;
    const s = new Set(allow);
    return this.interfaces.filter(x => s.has(x.ifname));
  },
  isAllowed(ifname) {
    const allow = this.cfg && this.cfg.allowed_interfaces;
    return !allow || allow.length === 0 || allow.includes(ifname);
  },

  async changePassword() {
    if (IS_MOCK) { alert("Mock 모드에서는 비밀번호 변경이 동작하지 않습니다."); return; }
    const np = prompt("새 비밀번호 (최소 4자):");
    if (!np) return;
    const r = await this.api("/api/password", { new_password: np });
    if (!r) return;
    if (r.ok) { this.setStatus("비밀번호 변경 완료", "ok"); setTimeout(() => location.reload(), 1000); }
    else      { this.setStatus("실패: " + r.error, "err"); }
  },

  /* ---------- Allowed-interfaces modal ---------- */

  openAllowedIfaces() {
    const allow = new Set(this.cfg.allowed_interfaces || []);
    const all = (this.interfaces || []).filter(x => x.ifname !== "lo" && x.ifname !== "lo0");
    const listEl = document.getElementById("ifaces-list");
    listEl.innerHTML = all.map(x => {
      const hint = friendlyIfaceLabel(x);
      const meta = [x.operstate, x.address].filter(Boolean).map(esc).join(" · ");
      return `
        <label class="iface-row">
          <input type="checkbox" data-allow="${esc(x.ifname)}"
                 ${allow.size === 0 || allow.has(x.ifname) ? "checked" : ""}>
          <div class="iface-row-text">
            <div class="iface-row-name">
              <code>${esc(x.ifname)}</code>
              ${hint ? `<span class="iface-hint">${esc(hint)}</span>` : ""}
            </div>
            ${meta ? `<div class="iface-meta">${meta}</div>` : ""}
          </div>
        </label>
      `;
    }).join("") || `<div class="hint">시스템 인터페이스를 가져오지 못했습니다.</div>`;

    const allCb = document.getElementById("ifaces-all");
    allCb.checked = allow.size === 0;
    allCb.onchange = () => {
      const on = allCb.checked;
      listEl.querySelectorAll("input[data-allow]").forEach(cb => {
        cb.checked = on;
        cb.disabled = on;
      });
      this._refreshIfaceModalWarn();
    };
    // initial enabled-state of the per-row checkboxes
    listEl.querySelectorAll("input[data-allow]").forEach(cb => {
      cb.disabled = allCb.checked;
      cb.onchange = () => this._refreshIfaceModalWarn();
    });
    this._refreshIfaceModalWarn();
    document.getElementById("ifaces-modal").classList.remove("hidden");
  },

  _refreshIfaceModalWarn() {
    const allCb = document.getElementById("ifaces-all");
    const picked = new Set();
    document.querySelectorAll("#ifaces-list input[data-allow]").forEach(cb => {
      if (cb.checked) picked.add(cb.dataset.allow);
    });
    const effective = allCb.checked ? null : picked;     // null = all allowed
    const stranded = (this.cfg.nodes || []).filter(n => n.iface && effective && !effective.has(n.iface));
    const warnEl = document.getElementById("ifaces-warn");
    warnEl.textContent = stranded.length
      ? `⚠ 적용 후 ${stranded.length}개 노드의 인터페이스가 비허용 상태가 됩니다: `
        + stranded.map(n => `${n.id}/${n.iface}`).join(", ")
      : "";
  },

  closeAllowedIfaces(apply) {
    if (apply) {
      const allCb = document.getElementById("ifaces-all");
      if (allCb.checked) {
        this.cfg.allowed_interfaces = [];
      } else {
        const picked = [];
        document.querySelectorAll("#ifaces-list input[data-allow]").forEach(cb => {
          if (cb.checked) picked.push(cb.dataset.allow);
        });
        this.cfg.allowed_interfaces = picked;
      }
      this.render();
    }
    document.getElementById("ifaces-modal").classList.add("hidden");
  },

  /* ---------- Wi-Fi modal ---------- */

  openWifi() {
    const w = this.cfg.wifi || {};
    const form = document.getElementById("wifi-form");
    form.innerHTML = `
      <label><input type="checkbox" id="w-en" ${w.enabled ? "checked" : ""}> 활성</label>
      <label>SSID</label><input id="w-ssid" value="${esc(w.ssid || "")}">
      <label>Channel</label><input id="w-ch" type="number" value="${w.channel || 6}">
      <label>HW Mode</label>
      <select id="w-hw">${["a","b","g","n","ac"].map(m => `<option ${m === w.hw_mode ? "selected" : ""}>${m}</option>`).join("")}</select>
      <label>WPA Passphrase</label><input id="w-pw" value="${esc(w.wpa_passphrase || "")}">
      <label>Country Code (2)</label><input id="w-cc" maxlength="2" value="${esc(w.country_code || "KR")}">
    `;
    document.getElementById("wifi-modal").classList.remove("hidden");
  },

  closeWifi(apply) {
    if (apply) {
      const w = this.cfg.wifi || (this.cfg.wifi = {});
      w.enabled        = document.getElementById("w-en").checked;
      w.ssid           = document.getElementById("w-ssid").value;
      w.channel        = parseInt(document.getElementById("w-ch").value) || 6;
      w.hw_mode        = document.getElementById("w-hw").value;
      w.wpa_passphrase = document.getElementById("w-pw").value;
      w.country_code   = (document.getElementById("w-cc").value || "KR").toUpperCase();
    }
    document.getElementById("wifi-modal").classList.add("hidden");
  },

  /* ---------- Commands modal ---------- */

  openCommands() {
    const text = this.generateCommands(this.cfg);
    document.getElementById("commands-output").textContent = text;
    document.getElementById("commands-modal").classList.remove("hidden");
  },
  closeCommands() { document.getElementById("commands-modal").classList.add("hidden"); },

  commandsCopy() {
    const text = document.getElementById("commands-output").textContent || "";
    navigator.clipboard.writeText(text)
      .then(() => this.setStatus("명령 복사됨", "ok"))
      .catch(() => this.setStatus("복사 실패 — 직접 선택해 주세요", "err"));
  },
  commandsDownload() {
    const text = document.getElementById("commands-output").textContent || "";
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement("a"), { href: url, download: "wne-commands.sh" });
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  },
  commandsEmail() {
    const text = document.getElementById("commands-output").textContent || "";
    const subj = encodeURIComponent("WNE — applied commands");
    const body = encodeURIComponent(text.slice(0, 7000));   // mailto cap
    location.href = `mailto:?subject=${subj}&body=${body}`;
  },

  /* Generate a readable, copy-pasteable script that mirrors what the controller
     would do for the current edited config. Best-effort approximation; the
     daemon is still the source of truth at apply time. */
  generateCommands(cfg) {
    const lines = [];
    const isMac = /Mac/.test(navigator.platform);
    lines.push(`#!/bin/sh`);
    lines.push(`# WNE — generated ${new Date().toISOString()}`);
    lines.push(`# Target: ${isMac ? "macOS (ifconfig / pfctl / dnctl)" : "Linux (iproute2 / tc / nft)"}`);
    lines.push(`# Hint: this is a preview. Edits take effect only after [저장 및 적용].`);
    lines.push("");

    if (isMac) {
      lines.push("# ---- per-node link state ----");
      (cfg.nodes || []).forEach(n => {
        if (!n.iface) return;
        lines.push(`ifconfig ${n.iface} ${n.up === false ? "down" : "up"}`);
      });
      lines.push("");
      let pipe = 1;
      (cfg.bridges || []).forEach((b, idx) => {
        lines.push(`# ---- bridge ${b.id} (${b.enabled === false ? "DISABLED" : "enabled"}) ----`);
        if (b.enabled === false) { lines.push(`# (skipped — bridge disabled)\n`); return; }
        const brName = `bridge${100 + idx}`;
        lines.push(`ifconfig ${brName} create`);
        (b.members || []).forEach(m => {
          const n = (cfg.nodes || []).find(x => x.id === m);
          if (!n || n.up === false) return;
          lines.push(`ifconfig ${brName} addm ${n.iface}`);
        });
        lines.push(`ifconfig ${brName} up`);
        const imp = b.impairments || {};
        if (!imp.bypass) {
          if (imp.delay_ms || imp.bandwidth_kbps || (imp.loss && imp.loss.mode === "percent")) {
            const parts = [];
            if (imp.delay_ms)       parts.push(`delay ${imp.delay_ms}`);
            if (imp.bandwidth_kbps) parts.push(`bw ${imp.bandwidth_kbps}Kbit/s`);
            if (imp.loss && imp.loss.mode === "percent" && imp.loss.percent != null) parts.push(`plr ${imp.loss.percent/100}`);
            lines.push(`dnctl pipe ${pipe} config ${parts.join(" ")}`);
            const dir = b.direction || "both";
            const member = (cfg.nodes || []).find(x => x.id === b.members[0]);
            const other  = (cfg.nodes || []).find(x => x.id === b.members[1]);
            if (member && other) {
              if (dir === "l2r" || dir === "both")
                lines.push(`echo 'dummynet out on ${other.iface}  pipe ${pipe}' | pfctl -a wne/${b.id} -f -`);
              if (dir === "r2l" || dir === "both")
                lines.push(`echo 'dummynet out on ${member.iface} pipe ${pipe}' | pfctl -a wne/${b.id} -f -`);
            }
            pipe++;
          }
          if (imp.loss && (imp.loss.mode === "pattern" || imp.loss.mode === "every_n")) {
            lines.push(`# loss mode=${imp.loss.mode}, dir=${b.direction || "both"} — handled in userspace pcap_worker`);
          }
        }
        lines.push("");
      });
    } else {
      lines.push("# ---- per-node link state ----");
      (cfg.nodes || []).forEach(n => {
        if (!n.iface) return;
        lines.push(`ip link set dev ${n.iface} ${n.up === false ? "down" : "up"}`);
      });
      lines.push("");
      lines.push("nft delete table bridge wne 2>/dev/null; nft add table bridge wne");
      lines.push("");
      let qnum = 1;
      (cfg.bridges || []).forEach(b => {
        lines.push(`# ---- bridge ${b.id} (${b.enabled === false ? "DISABLED" : "enabled"}) ----`);
        if (b.enabled === false) { lines.push(`# (skipped — bridge disabled)\n`); return; }
        lines.push(`ip link add name ${b.id} type bridge`);
        lines.push(`ip link set ${b.id} up`);
        (b.members || []).forEach(m => {
          const n = (cfg.nodes || []).find(x => x.id === m);
          if (!n || n.up === false) return;
          if (n.type === "WiFi") { lines.push(`# WiFi node ${n.id} — attached by hostapd (bridge=${b.id})`); return; }
          lines.push(`ip link set dev ${n.iface} master ${b.id}`);
          lines.push(`ip link set dev ${n.iface} up`);
        });
        const imp = b.impairments || {};
        if (imp.bypass) { lines.push(`# bypass — no tc/nft impairments\n`); return; }
        const dir = b.direction || "both";
        const L = (cfg.nodes || []).find(x => x.id === b.members[0]);
        const R = (cfg.nodes || []).find(x => x.id === b.members[1]);
        const lossPct = (imp.loss && imp.loss.mode === "percent") ? imp.loss.percent : null;
        const tcOn = (iface, withLoss) => {
          const parts = ["root", "netem"];
          if (imp.delay_ms)  parts.push(`delay ${imp.delay_ms}ms${imp.jitter_ms ? " " + imp.jitter_ms + "ms" : ""}`);
          if (withLoss != null) parts.push(`loss ${withLoss}%`);
          lines.push(`tc qdisc replace dev ${iface} ${parts.join(" ")}`);
          if (imp.bandwidth_kbps) lines.push(`tc qdisc add dev ${iface} parent 1: handle 2: tbf rate ${imp.bandwidth_kbps}kbit burst 32kbit latency 50ms`);
        };
        if (L && L.up !== false) tcOn(L.iface, (lossPct != null && (dir === "both" || dir === "r2l")) ? lossPct : null);
        if (R && R.up !== false) tcOn(R.iface, (lossPct != null && (dir === "both" || dir === "l2r")) ? lossPct : null);
        if (imp.loss && (imp.loss.mode === "pattern" || imp.loss.mode === "every_n")) {
          const targets = dir === "l2r" ? [L] : dir === "r2l" ? [R] : [L, R];
          targets.filter(n => n && n.up !== false).forEach(n => {
            lines.push(`nft add rule bridge wne forward iif ${n.iface} queue num ${qnum}    # ${imp.loss.mode}=${imp.loss.pattern || imp.loss.n}`);
            qnum++;
          });
        }
        lines.push("");
      });
      if (cfg.wifi && cfg.wifi.enabled) {
        lines.push("# ---- hostapd ----");
        lines.push(`# /run/wne/hostapd.conf is regenerated; hostapd -B used.`);
      }
    }
    return lines.join("\n");
  },
};

/* ---------------- Utils ---------------- */

function svgEl(tag, attrs, text) {
  const e = document.createElementNS(SVG_NS, tag);
  if (attrs) for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (text !== undefined) e.textContent = text;
  return e;
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

WNE.init();
