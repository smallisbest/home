"""Entrypoint: `python3 -m wne.web` starts the web server.

Bind host/port come from the daemon's config so admin changes take effect on restart.
"""
from __future__ import annotations

import logging
import sys

import uvicorn

from .. import ipc
from .app import app


def main() -> None:
    logging.basicConfig(level="INFO", format="%(asctime)s %(levelname)s [%(name)s] %(message)s")
    try:
        resp = ipc.call("get_config", timeout=5.0)
    except Exception as e:
        print(f"ERROR: cannot reach wned daemon: {e}", file=sys.stderr)
        sys.exit(1)
    if not resp.get("ok"):
        print(f"ERROR: daemon returned: {resp}", file=sys.stderr)
        sys.exit(1)
    web = resp["config"]["web"]
    uvicorn.run(app, host=web["host"], port=int(web["port"]), log_level="info")


if __name__ == "__main__":
    main()
