"""FastAPI web interface for WNE.

Talks to the daemon via Unix socket. Basic-auth using the user list in config.
Default credentials: admin / admin (change immediately).
"""
from __future__ import annotations

import secrets
from pathlib import Path

import bcrypt
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.responses import FileResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.staticfiles import StaticFiles

from .. import ipc

app = FastAPI(title="WNE — Network Emulator")
security = HTTPBasic()

STATIC_DIR = Path(__file__).parent / "static"


def authenticate(creds: HTTPBasicCredentials = Depends(security)) -> str:
    resp = ipc.call("get_config")
    if not resp.get("ok"):
        raise HTTPException(503, "daemon unavailable")
    users = resp["config"]["web"]["users"]
    for u in users:
        # constant-time username compare to avoid leaking which users exist
        if secrets.compare_digest(u["username"], creds.username):
            if bcrypt.checkpw(creds.password.encode(), u["password_hash"].encode()):
                return creds.username
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="invalid credentials",
        headers={"WWW-Authenticate": "Basic"},
    )


@app.get("/api/config")
def get_config(user: str = Depends(authenticate)):
    return ipc.call("get_config")


@app.post("/api/config")
def set_config(cfg: dict, user: str = Depends(authenticate)):
    # Preserve existing users (web UI doesn't edit them directly)
    current = ipc.call("get_config")
    if current.get("ok"):
        cfg.setdefault("web", {})
        cfg["web"]["users"] = current["config"]["web"]["users"]
        cfg["web"].setdefault("host", current["config"]["web"]["host"])
        cfg["web"].setdefault("port", current["config"]["web"]["port"])
    return ipc.call("set_config", config=cfg)


@app.get("/api/interfaces")
def list_ifaces(user: str = Depends(authenticate)):
    return ipc.call("list_interfaces")


@app.get("/api/status")
def status_(user: str = Depends(authenticate)):
    return ipc.call("status")


@app.post("/api/reload")
def reload_cfg(user: str = Depends(authenticate)):
    return ipc.call("reload")


@app.post("/api/password")
def change_password(body: dict, user: str = Depends(authenticate)):
    new_pw = (body or {}).get("new_password", "")
    if len(new_pw) < 4:
        raise HTTPException(400, "password must be at least 4 chars")
    resp = ipc.call("get_config")
    if not resp.get("ok"):
        raise HTTPException(503, "daemon unavailable")
    cfg = resp["config"]
    for u in cfg["web"]["users"]:
        if u["username"] == user:
            u["password_hash"] = bcrypt.hashpw(new_pw.encode(), bcrypt.gensalt()).decode()
            break
    return ipc.call("set_config", config=cfg)


# Serve index + assets at root.  The HTML uses *relative* paths
# (style.css, app.js) so the same file works both when served here
# and when opened directly via file:// (mock mode).
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static-legacy")


@app.get("/")
def index():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/style.css")
def style_css():
    return FileResponse(STATIC_DIR / "style.css", media_type="text/css")


@app.get("/app.js")
def app_js():
    return FileResponse(STATIC_DIR / "app.js", media_type="application/javascript")
