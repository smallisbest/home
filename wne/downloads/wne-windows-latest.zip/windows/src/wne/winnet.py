"""Windows network wrappers around PowerShell / netsh.

Counterpart to Linux `netlink.py` and macOS `bsdnet.py` — same shape of
operations, but backed by PowerShell cmdlets. All interface operations
require Administrator privileges (WNE daemon runs as SYSTEM).
"""
from __future__ import annotations

import json
import logging
import shlex
import subprocess

log = logging.getLogger("wne.winnet")


def run(cmd: list[str], check: bool = True, capture: bool = False) -> subprocess.CompletedProcess:
    log.debug("$ %s", " ".join(shlex.quote(c) for c in cmd))
    return subprocess.run(cmd, check=check, capture_output=capture, text=True)


def _ps(script: str, capture: bool = True) -> subprocess.CompletedProcess:
    """Run a PowerShell script block with output as UTF-8 JSON (usually)."""
    return run(
        ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
        check=True, capture=capture,
    )


def list_links() -> list[dict]:
    """Return a Linux-ish [{ifname, address, operstate, kind, master}] list.

    Uses `Get-NetAdapter` which enumerates all network adapters visible to
    the Windows TCP/IP stack, including virtual ones.
    """
    script = (
        "Get-NetAdapter -IncludeHidden | "
        "Select-Object Name, InterfaceDescription, Status, MacAddress, InterfaceIndex, "
        "MediaType, PhysicalMediaType, Virtual | "
        "ConvertTo-Json -Depth 3 -Compress"
    )
    p = _ps(script)
    raw = p.stdout.strip() or "[]"
    data = json.loads(raw)
    if isinstance(data, dict):
        data = [data]
    out: list[dict] = []
    for entry in data:
        name = entry.get("Name", "")
        mac = (entry.get("MacAddress") or "").replace("-", ":").lower() or None
        media = (entry.get("PhysicalMediaType") or entry.get("MediaType") or "").lower()
        kind = (
            "wireless" if "80211" in media or "wifi" in media or "wireless" in media
            else "ethernet" if "802.3" in media or "ethernet" in media
            else None
        )
        out.append({
            "ifname": name,
            "address": mac,
            "operstate": "UP" if entry.get("Status") in ("Up", 1) else "DOWN",
            "kind": kind,
            "master": None,
            "index": entry.get("InterfaceIndex"),
            "description": entry.get("InterfaceDescription"),
            "virtual": bool(entry.get("Virtual")),
        })
    return out


def link_exists(name: str) -> bool:
    return any(l["ifname"] == name for l in list_links())


def link_index(name: str) -> int | None:
    for l in list_links():
        if l["ifname"] == name:
            return l.get("index")
    return None


def link_up(name: str) -> None:
    _ps(f"Enable-NetAdapter -Name {json.dumps(name)} -Confirm:$false", capture=False)


def link_down(name: str) -> None:
    _ps(f"Disable-NetAdapter -Name {json.dumps(name)} -Confirm:$false", capture=False)


# ---------------- Wi-Fi hosted network ----------------
#
# Windows has three AP-ish mechanisms:
#   1. `netsh wlan set hostednetwork` (deprecated but still works on most SKUs)
#   2. Mobile Hotspot (Windows 10+ WinRT NetworkOperatorTetheringManager)
#   3. Wi-Fi Direct
#
# WNE uses (1) because it's the only fully scriptable one from an unattended
# service context. Wireless driver support varies; run `netsh wlan show drivers`
# to check "Hosted network supported : Yes".

def hosted_network_configure(ssid: str, passphrase: str) -> None:
    _ps(
        f"netsh wlan set hostednetwork mode=allow "
        f"ssid={json.dumps(ssid)} key={json.dumps(passphrase)} keyUsage=persistent",
        capture=False,
    )


def hosted_network_start() -> None:
    _ps("netsh wlan start hostednetwork", capture=False)


def hosted_network_stop() -> None:
    _ps("netsh wlan stop hostednetwork", capture=False)
