"""Loopback-TCP JSON client for talking to wned (Windows).

The daemon binds 127.0.0.1:<port> (default 47108); only local processes can
reach it. Same JSON-line protocol as the Linux / macOS UDS version.
"""
from __future__ import annotations

import json
import socket

DAEMON_HOST = "127.0.0.1"
DAEMON_PORT = 47108


def call(op: str, timeout: float = 10.0, **kwargs) -> dict:
    req = {"op": op, **kwargs}
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    s.connect((DAEMON_HOST, DAEMON_PORT))
    try:
        s.sendall((json.dumps(req) + "\n").encode())
        data = b""
        while b"\n" not in data:
            chunk = s.recv(65536)
            if not chunk:
                break
            data += chunk
    finally:
        s.close()
    line, _, _ = data.partition(b"\n")
    return json.loads(line.decode()) if line else {"ok": False, "error": "empty response"}
