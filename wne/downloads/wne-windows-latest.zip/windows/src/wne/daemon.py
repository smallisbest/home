"""wned — Network Emulator daemon (Windows).

Listens on 127.0.0.1:47108 for JSON control messages from the web UI / CLI.
Owns the live system state (per-node up/down, userspace bridge worker,
netsh hosted network).

Must run with Administrator rights.
"""
from __future__ import annotations

import json
import logging
import os
import socket
import sys
import threading
from pathlib import Path

from .config import Config, CONFIG_PATH, load_config, save_config
from .controller import Controller
from . import winnet as nl
from .ipc import DAEMON_HOST, DAEMON_PORT

log = logging.getLogger("wne.daemon")


class Daemon:
    def __init__(self):
        self.controller = Controller()
        self.config = load_config()
        self.lock = threading.Lock()
        self.stop_event = threading.Event()

    # ---------------- Handlers ----------------

    def handle(self, req: dict) -> dict:
        op = req.get("op")
        try:
            if op == "get_config":
                return {"ok": True, "config": self.config.model_dump()}

            if op == "set_config":
                try:
                    new_cfg = Config.model_validate(req["config"])
                except Exception as e:
                    return {"ok": False, "error": f"invalid config: {e}"}
                with self.lock:
                    self.config = new_cfg
                    save_config(self.config)
                    self.controller.apply(self.config)
                return {"ok": True}

            if op == "reload":
                with self.lock:
                    self.config = load_config()
                    self.controller.apply(self.config)
                return {"ok": True}

            if op == "list_interfaces":
                return {"ok": True, "interfaces": nl.list_links()}

            if op == "status":
                return {
                    "ok": True,
                    "bridges": sorted(self.controller.applied_bridges),
                    "config_path": str(CONFIG_PATH),
                }

            return {"ok": False, "error": f"unknown op: {op}"}
        except Exception as e:
            log.exception("handler error")
            return {"ok": False, "error": str(e)}

    # ---------------- TCP loopback server ----------------

    def serve(self) -> None:
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((DAEMON_HOST, DAEMON_PORT))
        srv.listen(8)
        log.info("listening on %s:%d", DAEMON_HOST, DAEMON_PORT)

        # Apply config at startup.
        try:
            with self.lock:
                self.controller.apply(self.config)
        except Exception:
            log.exception("initial apply failed")

        srv.settimeout(1.0)
        try:
            while not self.stop_event.is_set():
                try:
                    conn, _ = srv.accept()
                except socket.timeout:
                    continue
                threading.Thread(target=self._serve_conn, args=(conn,), daemon=True).start()
        finally:
            srv.close()

    def _serve_conn(self, conn: socket.socket) -> None:
        try:
            data = b""
            while b"\n" not in data:
                chunk = conn.recv(65536)
                if not chunk:
                    break
                data += chunk
                if len(data) > 4 * 1024 * 1024:
                    raise ValueError("request too large")
            line, _, _ = data.partition(b"\n")
            req = json.loads(line.decode())
            resp = self.handle(req)
        except Exception as e:
            resp = {"ok": False, "error": str(e)}
        try:
            conn.sendall((json.dumps(resp) + "\n").encode())
        except Exception:
            pass
        finally:
            conn.close()

    def shutdown(self) -> None:
        log.info("shutting down")
        self.stop_event.set()
        try:
            self.controller.teardown()
        except Exception:
            log.exception("teardown error")


def main() -> None:
    logging.basicConfig(
        level=os.environ.get("WNE_LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )
    d = Daemon()

    try:
        d.serve()
    except KeyboardInterrupt:
        d.shutdown()
        sys.exit(0)


if __name__ == "__main__":
    main()
