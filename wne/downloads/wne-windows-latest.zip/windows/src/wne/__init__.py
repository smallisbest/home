"""WNE — Windows build.

Same config schema and Web UI as the Linux / macOS builds. The kernel-level
mechanism differs: L2 forwarding + all impairments happen inside a single
userspace worker (`bridge_worker.py`) that uses Npcap (via scapy) for capture
and re-injection.
"""
