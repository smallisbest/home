# WNE — Windows installer
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File .\install.ps1
#
# Requirements:
#   • Windows 10 / 11 / Server 2019+
#   • Python 3.10+ in PATH  (winget install Python.Python.3.12)
#   • Npcap installed with WinPcap-compatible mode
#     (https://npcap.com/#download — check "Install Npcap in WinPcap API-compatible Mode")
#   • Administrator privileges (script auto-elevates)

param(
    [string]$InstallRoot = "C:\ProgramData\wne",
    [switch]$SkipDeps
)

# --- self-elevate --------------------------------------------------------------
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Re-launching elevated..."
    Start-Process -FilePath 'powershell.exe' `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -InstallRoot `"$InstallRoot`"" `
        -Verb RunAs
    exit
}

$ErrorActionPreference = 'Stop'
$SRC = Split-Path -Parent $PSCommandPath

Write-Host "== WNE installer ==" -ForegroundColor Cyan
Write-Host "  source     : $SRC"
Write-Host "  install to : $InstallRoot`n"

# --- 1) sanity checks ----------------------------------------------------------
$py = Get-Command python -ErrorAction SilentlyContinue
if (-not $py) { throw "python.exe not in PATH. Install Python 3.10+ (winget install Python.Python.3.12) and retry." }
Write-Host "[1/6] python : $($py.Source)"

# Npcap installed? Registry hint:
$npcap = Test-Path 'HKLM:\SOFTWARE\WOW6432Node\Npcap' -PathType Container `
     -or Test-Path 'HKLM:\SOFTWARE\Npcap' -PathType Container
if (-not $npcap) {
    Write-Warning "Npcap does not appear to be installed. scapy will fall back to Winsock RAW sockets and cannot capture L2 frames."
    Write-Warning "  Install from https://npcap.com/#download and re-run this script."
}

# --- 2) copy sources -----------------------------------------------------------
Write-Host "[2/6] copy sources to $InstallRoot"
New-Item -Force -ItemType Directory -Path $InstallRoot | Out-Null
New-Item -Force -ItemType Directory -Path "$InstallRoot\logs" | Out-Null
New-Item -Force -ItemType Directory -Path "$InstallRoot\run"  | Out-Null
robocopy "$SRC\src\wne" "$InstallRoot\wne" /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
Copy-Item "$SRC\config\config.example.json" "$InstallRoot\config.example.json" -Force
if (-not (Test-Path "$InstallRoot\config.json")) {
    Copy-Item "$SRC\config\config.example.json" "$InstallRoot\config.json"
}

# --- 3) venv + deps ------------------------------------------------------------
$venv = "$InstallRoot\venv"
if (-not (Test-Path "$venv\Scripts\python.exe")) {
    Write-Host "[3/6] create venv"
    & python -m venv $venv
} else {
    Write-Host "[3/6] venv exists — skipping create"
}
if (-not $SkipDeps) {
    Write-Host "[3/6] install pip packages"
    & "$venv\Scripts\python.exe" -m pip install --upgrade --quiet pip wheel
    & "$venv\Scripts\python.exe" -m pip install --quiet `
        "fastapi==0.115.*" `
        "uvicorn[standard]==0.32.*" `
        "pydantic==2.*" `
        bcrypt `
        scapy `
        pywin32
}

# --- 4) CLI shims (wnectl.cmd, wne-daemon.cmd, wne-web.cmd) --------------------
Write-Host "[4/6] CLI shims"
$shims = "$InstallRoot\bin"
New-Item -Force -ItemType Directory -Path $shims | Out-Null

@"
@echo off
"$venv\Scripts\python.exe" "$SRC\bin\wnectl.py" %*
"@ | Out-File -FilePath "$shims\wnectl.cmd" -Encoding ASCII -Force

@"
@echo off
"$venv\Scripts\python.exe" -m wne.daemon
"@ | Out-File -FilePath "$shims\wne-daemon.cmd" -Encoding ASCII -Force

@"
@echo off
set PYTHONPATH=$InstallRoot
"$venv\Scripts\python.exe" -m uvicorn wne.web.app:app --host 0.0.0.0 --port 8080
"@ | Out-File -FilePath "$shims\wne-web.cmd" -Encoding ASCII -Force

# --- 5) scheduled tasks (auto-start at boot as SYSTEM) ------------------------
Write-Host "[5/6] register scheduled tasks (SYSTEM, at boot)"
$daemon = "$shims\wne-daemon.cmd"
$web    = "$shims\wne-web.cmd"

Unregister-ScheduledTask -TaskName 'wned'    -Confirm:$false -ErrorAction SilentlyContinue
Unregister-ScheduledTask -TaskName 'wne-web' -Confirm:$false -ErrorAction SilentlyContinue

$trigger  = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
                -Compatibility Win8 -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartInterval (New-TimeSpan -Minutes 1) -RestartCount 3
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -RunLevel Highest

Register-ScheduledTask -TaskName 'wned'    -Action (New-ScheduledTaskAction -Execute $daemon) `
    -Trigger $trigger -Settings $settings -Principal $principal -Description 'WNE daemon' | Out-Null
Register-ScheduledTask -TaskName 'wne-web' -Action (New-ScheduledTaskAction -Execute $web) `
    -Trigger $trigger -Settings $settings -Principal $principal -Description 'WNE web UI' | Out-Null

# --- 6) firewall + start now --------------------------------------------------
Write-Host "[6/6] firewall + start"
New-NetFirewallRule -DisplayName 'WNE web UI (8080)' -Direction Inbound -Protocol TCP `
    -LocalPort 8080 -Action Allow -ErrorAction SilentlyContinue | Out-Null
New-NetFirewallRule -DisplayName 'WNE daemon (loopback)' -Direction Inbound -Protocol TCP `
    -LocalPort 47108 -RemoteAddress 127.0.0.1 -Action Allow -ErrorAction SilentlyContinue | Out-Null

Start-ScheduledTask -TaskName wned
Start-Sleep -Seconds 1
Start-ScheduledTask -TaskName wne-web

Write-Host ""
Write-Host "WNE installed." -ForegroundColor Green
Write-Host "  • Web UI:      http://localhost:8080  (admin / admin — change immediately)"
Write-Host "  • CLI:         $shims\wnectl.cmd status"
Write-Host "  • Config:      $InstallRoot\config.json"
Write-Host "  • Logs:        Task Scheduler → 'wned' / 'wne-web' history"
Write-Host ""
Write-Host "Notes:"
Write-Host "  • Wi-Fi AP uses `netsh wlan hostednetwork` — check driver support:"
Write-Host "      netsh wlan show drivers   ->  `"Hosted network supported : Yes`""
Write-Host "  • L2 forwarding + all impairments happen in the userspace bridge_worker"
Write-Host "    (Npcap-backed). Do NOT put the machine's primary NIC into a WNE bridge"
Write-Host "    unless you know what you're doing — it will go into promiscuous mode."
