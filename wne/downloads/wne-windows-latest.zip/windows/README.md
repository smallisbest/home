# WNE — Windows 빌드

Linux / macOS 빌드와 **동일한 config 스키마 / Web UI / CLI 명령**을 그대로 유지한
Windows 이식본. 커널 L2 브리지 API 가 Windows 에서 실질적으로 부재하기 때문에,
**L2 포워딩과 모든 임페어먼트를 하나의 유저 스페이스 워커** (`bridge_worker.py`)
에서 처리합니다. Npcap (via scapy) 로 프레임을 캡처하고, 손실 판단 → BW 토큰 →
delay/jitter 큐를 통과시킨 뒤 다른 쪽 iface 로 재주입합니다.

## 요구사항

- Windows 10 / 11 / Server 2019+
- **Python 3.10+** (`winget install Python.Python.3.12`)
- **Npcap** — https://npcap.com/#download
  - 설치 시 **"Install Npcap in WinPcap API-compatible Mode"** 체크
  - 없으면 L2 캡처가 안 되어 브리지가 동작하지 않습니다
- Administrator 권한 (설치 스크립트 자동 elevate)

## 설치

```powershell
git clone https://github.com/outsidus/wne.git
cd wne\windows
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

`install.ps1` 이 하는 일:

1. Python + Npcap 존재 확인
2. `C:\ProgramData\wne\` 에 소스 복사
3. `C:\ProgramData\wne\venv\` 에 venv 생성 + `fastapi / uvicorn / pydantic / bcrypt / scapy / pywin32` 설치
4. `wnectl.cmd / wne-daemon.cmd / wne-web.cmd` shim 생성
5. **Task Scheduler** 에 SYSTEM 계정 + `AtStartup` 트리거로 `wned` / `wne-web` 등록
6. 방화벽 규칙 (Web UI 8080, 데몬 loopback 47108)
7. 즉시 시작

## 사용

- Web UI: http://localhost:8080 (`admin` / `admin` — 즉시 변경)
- CLI: `wnectl.cmd status | interfaces | get | check`
- 설정: `C:\ProgramData\wne\config.json`
- 로그: Task Scheduler → 각 태스크 History 탭

## 아키텍처 차이 (Linux/macOS 대비)

| 항목 | Linux | macOS | **Windows** |
|---|---|---|---|
| L2 브리지 | `ip link add … type bridge` | `ifconfig bridge create` | **없음 — userspace via scapy** |
| Delay/Jitter/BW | `tc netem` + `tbf` | dummynet | **userspace queue + token bucket** |
| Percent loss | tc netem | dummynet plr | **userspace random** |
| Pattern/Every-N loss | NFQUEUE | pcap_worker | **동일 worker** |
| Wi-Fi AP | `hostapd` | 미지원 (Internet Sharing) | `netsh wlan hostednetwork` (deprecated) |
| IPC | Unix Domain Socket | Unix Domain Socket | **TCP loopback 127.0.0.1:47108** |
| 서비스 | systemd | launchd | **Task Scheduler (SYSTEM at boot)** |

**Windows 만의 특기 사항**:

- 모든 브리지가 유저 스페이스에서 흘러가므로 **처리량이 커널 브리지보다
  현저히 낮습니다** (수 백 Mbps 급). 임페어먼트 테스트/에뮬레이션 목적에는
  충분하지만 프로덕션 게이트웨이용은 아님.
- 브리지 멤버 iface 는 **promiscuous 모드로 진입**합니다. 호스트의 주 NIC
  (인터넷 붙어 있는 것) 를 함부로 멤버로 넣지 마세요.
- Wi-Fi AP 는 무선 드라이버가 "Hosted network supported : Yes" 여야 합니다:

  ```powershell
  netsh wlan show drivers
  ```

## 제거

```powershell
Unregister-ScheduledTask -TaskName wned    -Confirm:$false
Unregister-ScheduledTask -TaskName wne-web -Confirm:$false
Remove-NetFirewallRule -DisplayName 'WNE web UI (8080)' -ErrorAction SilentlyContinue
Remove-NetFirewallRule -DisplayName 'WNE daemon (loopback)' -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force C:\ProgramData\wne
```

## 트러블슈팅

| 증상 | 원인 / 해결 |
|---|---|
| `wnectl status` 가 connect refused | 데몬 미가동 → `Start-ScheduledTask wned` |
| 브리지 만들었는데 트래픽이 안 감 | Npcap 미설치 / WinPcap 호환 모드 해제 상태 |
| Wi-Fi AP 시작 실패 | `netsh wlan show drivers` 에서 hosted network 지원 여부 확인 |
| 설치 스크립트가 elevate 후 창이 사라짐 | `Start-Transcript` 로 로그 남기려면 스크립트 수동 실행 |
| `bridge_worker` 프로세스 CPU 100% | 대용량 트래픽 → 유저스페이스 병목. BW 를 낮추거나 트래픽 소스를 줄이기 |

## 개발

소스 수정 후 재기동:

```powershell
Stop-ScheduledTask  -TaskName wned
Stop-ScheduledTask  -TaskName wne-web
# (소스는 이미 C:\ProgramData\wne\wne\ 아래 있으므로 재복사가 필요하면)
robocopy .\src\wne C:\ProgramData\wne\wne /MIR /NFL /NDL /NJH /NJS
Start-ScheduledTask -TaskName wned
Start-ScheduledTask -TaskName wne-web
```

또는 포어그라운드로:

```powershell
C:\ProgramData\wne\venv\Scripts\python.exe -m wne.daemon   # 콘솔 1
C:\ProgramData\wne\venv\Scripts\python.exe -m wne.web      # 콘솔 2
```
