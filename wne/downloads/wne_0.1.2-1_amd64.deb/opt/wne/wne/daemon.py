"""wned — Network Emulator daemon.

Listens on a Unix socket for JSON control messages from the web UI / CLI.
Owns the live system state (bridges, tc, nftables, NFQ worker, hostapd).
"""
from __future__ import annotations

import json
import logging
import os
import signal
import socket
import sys
import threading
from pathlib import Path

from .config import Config, CONFIG_PATH, load_config, save_config
from .controller import Controller
from . import netlink as nl

log = logging.getLogger("wne.daemon")

SOCKET_PATH = Path("/run/wne/wned.sock")


class Daemon:
    def __init__(self):
        self.controller = Controller()
        self.config = load_config()
        self.lock = threading.Lock()
        self.stop_event = threading.Event()

    # ---------------- Handlers ----------------

    def handle(self, req: dict) -> dict:
        op = req.get("op")
        try:
            if op == "get_config":
                return {"ok": True, "config": self.config.model_dump()}

            if op == "set_config":
                try:
                    new_cfg = Config.model_validate(req["config"])
                except Exception as e:
                    return {"ok": False, "error": f"invalid config: {e}"}
                with self.lock:
                    self.config = new_cfg
                    save_config(self.config)
                    self.controller.apply(self.config)
                return {"ok": True}

            if op == "reload":
                with self.lock:
                    self.config = load_config()
                    self.controller.apply(self.config)
                return {"ok": True}

            if op == "list_interfaces":
                links = nl.list_links()
                ifaces = [
                    {
                        "ifname": l["ifname"],
                        "address": l.get("address"),
                        "operstate": l.get("operstate"),
                        "kind": (l.get("linkinfo") or {}).get("info_kind"),
                        "master": l.get("master"),
                    }
                    for l in links
                    if l["ifname"] != "lo"
                ]
                return {"ok": True, "interfaces": ifaces}

            if op == "status":
                return {
                    "ok": True,
                    "bridges": sorted(self.controller.applied_bridges),
                    "config_path": str(CONFIG_PATH),
                }

            return {"ok": False, "error": f"unknown op: {op}"}
        except Exception as e:
            log.exception("handler error")
            return {"ok": False, "error": str(e)}

    # ---------------- Socket server ----------------

    def serve(self) -> None:
        SOCKET_PATH.parent.mkdir(parents=True, exist_ok=True)
        if SOCKET_PATH.exists():
            SOCKET_PATH.unlink()
        srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        srv.bind(str(SOCKET_PATH))
        os.chmod(SOCKET_PATH, 0o660)
        srv.listen(8)
        log.info("listening on %s", SOCKET_PATH)

        # Apply config at startup.
        try:
            with self.lock:
                self.controller.apply(self.config)
        except Exception:
            log.exception("initial apply failed")

        srv.settimeout(1.0)
        try:
            while not self.stop_event.is_set():
                try:
                    conn, _ = srv.accept()
                except socket.timeout:
                    continue
                threading.Thread(target=self._serve_conn, args=(conn,), daemon=True).start()
        finally:
            srv.close()
            SOCKET_PATH.unlink(missing_ok=True)

    def _serve_conn(self, conn: socket.socket) -> None:
        try:
            data = b""
            while b"\n" not in data:
                chunk = conn.recv(65536)
                if not chunk:
                    break
                data += chunk
                if len(data) > 4 * 1024 * 1024:
                    raise ValueError("request too large")
            line, _, _ = data.partition(b"\n")
            req = json.loads(line.decode())
            resp = self.handle(req)
        except Exception as e:
            resp = {"ok": False, "error": str(e)}
        try:
            conn.sendall((json.dumps(resp) + "\n").encode())
        except Exception:
            pass
        finally:
            conn.close()

    def shutdown(self) -> None:
        log.info("shutting down")
        self.stop_event.set()
        try:
            self.controller.teardown()
        except Exception:
            log.exception("teardown error")


def main() -> None:
    logging.basicConfig(
        level=os.environ.get("WNE_LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )
    d = Daemon()

    def _term(signum, frame):
        d.shutdown()
        sys.exit(0)

    def _hup(signum, frame):
        log.info("SIGHUP — reloading config from disk")
        try:
            with d.lock:
                d.config = load_config()
                d.controller.apply(d.config)
        except Exception:
            log.exception("reload failed")

    signal.signal(signal.SIGTERM, _term)
    signal.signal(signal.SIGINT, _term)
    signal.signal(signal.SIGHUP, _hup)

    d.serve()


if __name__ == "__main__":
    main()
