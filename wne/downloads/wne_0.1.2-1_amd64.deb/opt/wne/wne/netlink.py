"""Thin wrappers around iproute2 / nftables CLI."""
from __future__ import annotations

import json
import logging
import shlex
import subprocess

log = logging.getLogger(__name__)


def run(cmd: list[str], check: bool = True, capture: bool = False) -> subprocess.CompletedProcess:
    log.debug("$ %s", " ".join(shlex.quote(c) for c in cmd))
    return subprocess.run(cmd, check=check, capture_output=capture, text=True)


def list_links() -> list[dict]:
    p = run(["ip", "-j", "link", "show"], capture=True)
    return json.loads(p.stdout)


def link_exists(name: str) -> bool:
    return any(link.get("ifname") == name for link in list_links())


def link_is_bridge_slave(name: str) -> str | None:
    for link in list_links():
        if link.get("ifname") == name:
            return link.get("master")
    return None


def bridge_create(name: str) -> None:
    if not link_exists(name):
        run(["ip", "link", "add", "name", name, "type", "bridge"])
    run(["ip", "link", "set", name, "up"])


def bridge_delete(name: str) -> None:
    if link_exists(name):
        run(["ip", "link", "set", name, "down"], check=False)
        run(["ip", "link", "delete", name, "type", "bridge"], check=False)


def link_set_master(iface: str, master: str) -> None:
    run(["ip", "link", "set", iface, "master", master])
    run(["ip", "link", "set", iface, "up"])


def link_unset_master(iface: str) -> None:
    run(["ip", "link", "set", iface, "nomaster"], check=False)


def tc_clear(iface: str) -> None:
    run(["tc", "qdisc", "del", "dev", iface, "root"], check=False)


def tc_apply(
    iface: str,
    loss_percent: float | None = None,
    delay_ms: float | None = None,
    jitter_ms: float | None = None,
    bandwidth_kbps: int | None = None,
) -> None:
    """Build a netem (+optional tbf child) qdisc chain on `iface`'s egress."""
    tc_clear(iface)

    netem_args: list[str] = []
    if delay_ms is not None and delay_ms > 0:
        netem_args += ["delay", f"{delay_ms}ms"]
        if jitter_ms is not None and jitter_ms > 0:
            netem_args += [f"{jitter_ms}ms"]
    elif jitter_ms is not None and jitter_ms > 0:
        netem_args += ["delay", "0ms", f"{jitter_ms}ms"]
    if loss_percent is not None and loss_percent > 0:
        netem_args += ["loss", f"{loss_percent}%"]

    has_netem = bool(netem_args)
    if has_netem:
        run(["tc", "qdisc", "add", "dev", iface, "root", "handle", "1:", "netem", *netem_args])

    if bandwidth_kbps is not None and bandwidth_kbps > 0:
        tbf = [
            "tc", "qdisc", "add", "dev", iface,
            *(["parent", "1:"] if has_netem else ["root"]),
            "handle", "2:" if has_netem else "1:",
            "tbf",
            "rate", f"{bandwidth_kbps}kbit",
            "burst", "32kbit",
            "latency", "50ms",
        ]
        run(tbf)


def nft_reset_table() -> None:
    """Recreate the bridge family table 'wne' from scratch."""
    run(["nft", "delete", "table", "bridge", "wne"], check=False)
    run(["nft", "add", "table", "bridge", "wne"])
    run([
        "nft", "add", "chain", "bridge", "wne", "forward",
        "{", "type", "filter", "hook", "forward", "priority", "0", ";",
        "policy", "accept", ";", "}",
    ])


def nft_queue_bridge(bridge_name: str, queue_num: int, iif: str | None = None) -> None:
    """Add a forward-hook rule that queues packets to NFQUEUE `queue_num`.

    If `iif` is set, only packets *entering* the bridge through that interface match,
    which lets us assign an independent NFQUEUE per direction (one per ingress port).
    """
    cmd = ["nft", "add", "rule", "bridge", "wne", "forward",
           "meta", "ibrname", bridge_name]
    if iif:
        cmd += ["iifname", iif]
    cmd += ["queue", "num", str(queue_num), "bypass"]
    run(cmd)


def nft_drop_table() -> None:
    run(["nft", "delete", "table", "bridge", "wne"], check=False)
