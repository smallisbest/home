"""Tiny Unix-socket JSON client for talking to wned."""
from __future__ import annotations

import json
import socket
from pathlib import Path

SOCKET_PATH = Path("/run/wne/wned.sock")


def call(op: str, timeout: float = 10.0, **kwargs) -> dict:
    req = {"op": op, **kwargs}
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(timeout)
    s.connect(str(SOCKET_PATH))
    try:
        s.sendall((json.dumps(req) + "\n").encode())
        data = b""
        while b"\n" not in data:
            chunk = s.recv(65536)
            if not chunk:
                break
            data += chunk
    finally:
        s.close()
    line, _, _ = data.partition(b"\n")
    return json.loads(line.decode()) if line else {"ok": False, "error": "empty response"}
