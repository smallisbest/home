"""Config schema and persistence."""
from __future__ import annotations

from pathlib import Path
from typing import Literal, Optional

import bcrypt
from pydantic import BaseModel, Field, field_validator


CONFIG_PATH = Path("/etc/wne/config.json")


class LossConfig(BaseModel):
    mode: Literal["percent", "every_n", "pattern"]
    percent: Optional[float] = None
    n: Optional[int] = None
    pattern: Optional[str] = None
    # Direction of loss application within the bridge.
    #   "both" — apply to packets entering on every member (default; per-ingress independent counters)
    #   "l2r" — only packets entering on members[0]  (Left → Right)
    #   "r2l" — only packets entering on members[1:] (Right → Left)
    #   "none" — loss configured but not applied (BW/Delay/Jitter still active)
    direction: Literal["both", "l2r", "r2l", "none"] = "both"

    @field_validator("pattern")
    @classmethod
    def _validate_pattern(cls, v):
        if v is None:
            return v
        if not v or any(c not in "01" for c in v):
            raise ValueError("pattern must be a non-empty string of 0/1")
        return v


class Impairments(BaseModel):
    bypass: bool = True
    loss: Optional[LossConfig] = None
    delay_ms: Optional[float] = None
    jitter_ms: Optional[float] = None
    bandwidth_kbps: Optional[int] = None


class Node(BaseModel):
    id: str
    iface: str
    type: Literal["LAN", "WiFi"] = "LAN"
    description: str = ""
    # When False the controller brings the iface down and excludes it from any bridge.
    up: bool = True

    @field_validator("type", mode="before")
    @classmethod
    def _normalize_type(cls, v):
        if isinstance(v, str):
            low = v.lower()
            if low == "lan":  return "LAN"
            if low == "wifi": return "WiFi"
        return v


class Bridge(BaseModel):
    id: str
    # Exactly two members: members[0] = L (Start), members[1] = R (Term).
    members: list[str] = Field(default_factory=list, max_length=2)
    # Traffic direction between L and R:
    #   "l2r"  — L → R only
    #   "r2l"  — L ← R only
    #   "both" — L ↔ R (default)
    direction: Literal["l2r", "r2l", "both"] = "both"
    # When False the controller does NOT create the bridge nor any tc/nft rules.
    enabled: bool = True
    impairments: Impairments = Field(default_factory=Impairments)


class WifiConfig(BaseModel):
    enabled: bool = False
    ssid: str = "WNE-AP"
    channel: int = 6
    hw_mode: Literal["a", "b", "g", "n", "ac"] = "g"
    wpa_passphrase: str = "changeme123"
    country_code: str = "KR"


class User(BaseModel):
    username: str
    password_hash: str


def _default_users() -> list[User]:
    return [
        User(
            username="admin",
            password_hash=bcrypt.hashpw(b"admin", bcrypt.gensalt()).decode(),
        )
    ]


class WebConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8080
    users: list[User] = Field(default_factory=_default_users)


class Config(BaseModel):
    version: int = 1
    web: WebConfig = Field(default_factory=WebConfig)
    wifi: WifiConfig = Field(default_factory=WifiConfig)
    # When non-empty only these system interfaces can be picked as a node iface,
    # appear in the seed, or be listed by the picker. Empty = no restriction.
    allowed_interfaces: list[str] = Field(default_factory=list)
    nodes: list[Node] = Field(default_factory=list)
    bridges: list[Bridge] = Field(default_factory=list)


def load_config(path: Path = CONFIG_PATH) -> Config:
    if not path.exists():
        cfg = Config(nodes=_seed_nodes_from_system())
        save_config(cfg, path)
        return cfg
    return Config.model_validate_json(path.read_text())


def _seed_nodes_from_system(allowed: list[str] | None = None) -> list[Node]:
    """Build one node per real system interface; no bridges, all up.

    If ``allowed`` is non-empty, only those ifnames are seeded.
    """
    try:
        from . import netlink as nl
        links = nl.list_links()
    except Exception:
        return []
    allow_set = set(allowed or [])
    seeded: list[Node] = []
    for l in links:
        ifname = l.get("ifname", "")
        if not ifname or ifname == "lo":
            continue
        if allow_set and ifname not in allow_set:
            continue
        kind = (l.get("linkinfo") or {}).get("info_kind")
        nodetype: Literal["LAN", "WiFi"] = "WiFi" if (kind == "wlan" or ifname.startswith("wl")) else "LAN"
        seeded.append(Node(id=ifname, iface=ifname, type=nodetype))
    return seeded


def save_config(cfg: Config, path: Path = CONFIG_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(cfg.model_dump_json(indent=2))
    tmp.replace(path)
