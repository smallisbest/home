"""Applies a Config to the running system: bridges, tc, nftables, hostapd, NFQ worker."""
from __future__ import annotations

import json
import logging
import os
import signal
import subprocess
import sys
from pathlib import Path

from . import netlink as nl
from .config import Config, Node

log = logging.getLogger("wne.ctrl")

RUN_DIR = Path("/run/wne")
NFQ_STATE_PATH = RUN_DIR / "nfq_state.json"
NFQ_PID_PATH = RUN_DIR / "nfq.pid"
HOSTAPD_CONF_PATH = RUN_DIR / "hostapd.conf"
HOSTAPD_PID_PATH = RUN_DIR / "hostapd.pid"


class Controller:
    def __init__(self):
        self.applied_bridges: set[str] = set()
        self.applied_member_ifaces: set[str] = set()
        RUN_DIR.mkdir(parents=True, exist_ok=True)

    # ---------------- Apply / teardown ----------------

    def apply(self, cfg: Config) -> None:
        log.info("applying configuration")

        # 1) Tear down anything we previously installed.
        self._stop_hostapd()
        self._teardown_existing()

        # 2) Fresh nftables bridge table.
        nl.nft_reset_table()

        node_by_id = {n.id: n for n in cfg.nodes}
        wifi_attach_bridge: dict[str, Node] = {}  # node_id -> bridge_id mapping recorded below

        nfq_state: dict[str, dict] = {}
        next_qnum = 1
        bridge_for_wifi_node: dict[str, str] = {}  # wifi_node_id -> bridge_id

        # Apply per-node up/down state (independent of bridge membership).
        for node in cfg.nodes:
            if not nl.link_exists(node.iface):
                continue
            try:
                nl.run(["ip", "link", "set", node.iface, "up" if node.up else "down"], check=False)
            except Exception:
                log.exception("link state change failed: %s", node.iface)

        # 3) Create bridges and enslave members.
        for br in cfg.bridges:
            if not br.enabled:
                log.info("bridge %s disabled — skipped", br.id)
                continue
            nl.bridge_create(br.id)
            self.applied_bridges.add(br.id)

            for member_id in br.members:
                node = node_by_id.get(member_id)
                if node is None:
                    log.warning("bridge %s references unknown node %s", br.id, member_id)
                    continue
                if not node.up:
                    log.info("bridge %s: skip down node %s", br.id, node.id)
                    continue
                if not nl.link_exists(node.iface):
                    log.warning("node %s: interface %s does not exist", node.id, node.iface)
                    continue
                if node.type == "WiFi":
                    # hostapd will attach this iface to the bridge via `bridge=<br>`
                    bridge_for_wifi_node[node.id] = br.id
                    continue
                nl.link_set_master(node.iface, br.id)
                self.applied_member_ifaces.add(node.iface)

            # 4) Impairments.
            imp = br.impairments
            if imp.bypass:
                continue

            # Resolve loss + direction.
            random_loss_pct: float | None = None
            loss_direction = "both"
            if imp.loss:
                loss_direction = imp.loss.direction
                if loss_direction != "none" and imp.loss.mode == "percent":
                    random_loss_pct = imp.loss.percent

            # Direction semantics (first member = L, others = R):
            #   percent (tc):   loss applied at egress of the *destination* side
            #                   L2R → tc loss on members[1+], R2L → tc loss on members[0]
            #   pattern/N (NFQ): loss applied at ingress of the *source* side
            #                   L2R → NFQ on members[0], R2L → NFQ on members[1+]
            # tc on every member iface (delay/jitter/BW always; loss only when direction allows)
            for idx, member_id in enumerate(br.members):
                node = node_by_id.get(member_id)
                if not node or not nl.link_exists(node.iface):
                    continue
                is_left = (idx == 0)
                # Egress at R (members[1+]) carries L→R traffic; egress at L carries R→L.
                apply_loss_here = False
                if random_loss_pct is not None:
                    if loss_direction == "both":
                        apply_loss_here = True
                    elif loss_direction == "l2r" and not is_left:
                        apply_loss_here = True
                    elif loss_direction == "r2l" and is_left:
                        apply_loss_here = True
                nl.tc_apply(
                    node.iface,
                    loss_percent=random_loss_pct if apply_loss_here else None,
                    delay_ms=imp.delay_ms,
                    jitter_ms=imp.jitter_ms,
                    bandwidth_kbps=imp.bandwidth_kbps,
                )
                self.applied_member_ifaces.add(node.iface)

            # NFQUEUE for pattern / every_n — direction filters which ingress ports get queued.
            #   both → every member (independent counter per direction)
            #   l2r  → members[0] only
            #   r2l  → members[1:] only
            #   none → no queue
            if imp.loss and imp.loss.mode in ("every_n", "pattern") and loss_direction != "none":
                for idx, member_id in enumerate(br.members):
                    node = node_by_id.get(member_id)
                    if node is None or not nl.link_exists(node.iface):
                        continue
                    is_left = (idx == 0)
                    if loss_direction == "both":
                        pass
                    elif loss_direction == "l2r" and not is_left:
                        continue
                    elif loss_direction == "r2l" and is_left:
                        continue
                    qnum = next_qnum
                    next_qnum += 1
                    nl.nft_queue_bridge(br.id, qnum, iif=node.iface)
                    nfq_state[str(qnum)] = {
                        "mode": imp.loss.mode,
                        "n": imp.loss.n or 0,
                        "pattern": imp.loss.pattern or "",
                        "bridge": br.id,
                        "ingress": node.iface,
                        "direction": loss_direction,
                    }

        # 5) NFQ worker.
        self._write_nfq_state(nfq_state)
        if nfq_state:
            self._start_nfq_worker()
        else:
            self._stop_nfq_worker()

        # 6) hostapd (after bridges are up so it can attach into one).
        if cfg.wifi.enabled:
            wifi_node = next((n for n in cfg.nodes if n.type == "WiFi"), None)
            if wifi_node is None:
                log.warning("wifi.enabled=true but no wifi node defined")
            elif not nl.link_exists(wifi_node.iface):
                log.warning("wifi node iface %s does not exist", wifi_node.iface)
            else:
                bridge_id = bridge_for_wifi_node.get(wifi_node.id)
                self._write_hostapd_conf(cfg, wifi_node.iface, bridge_id)
                self._start_hostapd()

        log.info("apply done: %d bridges, %d nfq rules", len(self.applied_bridges), len(nfq_state))

    def teardown(self) -> None:
        log.info("tearing down")
        self._stop_hostapd()
        self._stop_nfq_worker()
        self._teardown_existing()
        nl.nft_drop_table()

    def _teardown_existing(self) -> None:
        # Clear tc on every member iface we touched
        for iface in list(self.applied_member_ifaces):
            nl.tc_clear(iface)
            nl.link_unset_master(iface)
        self.applied_member_ifaces.clear()
        # Delete bridges we created
        for br in list(self.applied_bridges):
            for link in nl.list_links():
                if link.get("master") == br:
                    nl.link_unset_master(link["ifname"])
            nl.bridge_delete(br)
        self.applied_bridges.clear()

    # ---------------- NFQ worker subprocess ----------------

    def _write_nfq_state(self, state: dict) -> None:
        NFQ_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        NFQ_STATE_PATH.write_text(json.dumps(state, indent=2))

    def _start_nfq_worker(self) -> None:
        self._stop_nfq_worker()
        env = {**os.environ, "WNE_NFQ_STATE": str(NFQ_STATE_PATH)}
        # Use the same interpreter as the daemon
        p = subprocess.Popen(
            [sys.executable, "-m", "wne.nfq_worker"],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        NFQ_PID_PATH.write_text(str(p.pid))
        log.info("nfq worker started pid=%d", p.pid)

    def _stop_nfq_worker(self) -> None:
        if not NFQ_PID_PATH.exists():
            return
        try:
            pid = int(NFQ_PID_PATH.read_text().strip())
            os.kill(pid, signal.SIGTERM)
            log.info("nfq worker stopped pid=%d", pid)
        except (ProcessLookupError, ValueError):
            pass
        NFQ_PID_PATH.unlink(missing_ok=True)

    # ---------------- hostapd ----------------

    def _write_hostapd_conf(self, cfg: Config, iface: str, bridge: str | None) -> None:
        lines = [
            f"interface={iface}",
        ]
        if bridge:
            lines.append(f"bridge={bridge}")
        lines += [
            f"ssid={cfg.wifi.ssid}",
            f"hw_mode={cfg.wifi.hw_mode}",
            f"channel={cfg.wifi.channel}",
            f"country_code={cfg.wifi.country_code}",
            "ieee80211d=1",
            "ieee80211n=1",
            "wmm_enabled=1",
            "auth_algs=1",
            "wpa=2",
            f"wpa_passphrase={cfg.wifi.wpa_passphrase}",
            "wpa_key_mgmt=WPA-PSK",
            "rsn_pairwise=CCMP",
        ]
        HOSTAPD_CONF_PATH.parent.mkdir(parents=True, exist_ok=True)
        HOSTAPD_CONF_PATH.write_text("\n".join(lines) + "\n")

    def _start_hostapd(self) -> None:
        self._stop_hostapd()
        subprocess.Popen(
            ["hostapd", "-B", "-P", str(HOSTAPD_PID_PATH), str(HOSTAPD_CONF_PATH)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        log.info("hostapd started")

    def _stop_hostapd(self) -> None:
        if HOSTAPD_PID_PATH.exists():
            try:
                pid = int(HOSTAPD_PID_PATH.read_text().strip())
                os.kill(pid, signal.SIGTERM)
            except (ProcessLookupError, ValueError):
                pass
            HOSTAPD_PID_PATH.unlink(missing_ok=True)
