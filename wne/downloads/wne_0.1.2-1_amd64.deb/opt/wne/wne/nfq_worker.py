"""NFQUEUE worker: drops packets per-bridge using every-N or bit-pattern rules.

State file format (JSON):
    { "<queue_num>": {"mode": "every_n"|"pattern", "n": int, "pattern": "010..."} }

The daemon writes the state file then (re)starts this worker.
"""
from __future__ import annotations

import json
import logging
import os
import signal
import sys
import threading
from pathlib import Path

try:
    from netfilterqueue import NetfilterQueue
except ImportError:
    print("ERROR: python-netfilterqueue (NetfilterQueue) is not installed.", file=sys.stderr)
    sys.exit(1)

log = logging.getLogger("wne.nfq")


class BridgeLossState:
    """One counter+rule per NFQUEUE number; shared across both directions."""

    def __init__(self, mode: str, n: int = 0, pattern: str = ""):
        self.mode = mode
        self.n = max(0, int(n))
        self.pattern = pattern or ""
        self.counter = 0
        self.lock = threading.Lock()

    def should_drop(self) -> bool:
        with self.lock:
            if self.mode == "every_n" and self.n > 0:
                self.counter = (self.counter + 1) % self.n
                # Drop the N-th packet (when counter wraps back to 0)
                return self.counter == 0
            if self.mode == "pattern" and self.pattern:
                idx = self.counter % len(self.pattern)
                self.counter += 1
                return self.pattern[idx] == "1"
            return False


def load_states(state_file: Path) -> dict[int, BridgeLossState]:
    if not state_file.exists():
        return {}
    data = json.loads(state_file.read_text())
    return {
        int(qnum): BridgeLossState(cfg["mode"], cfg.get("n", 0), cfg.get("pattern", ""))
        for qnum, cfg in data.items()
    }


def main() -> None:
    logging.basicConfig(
        level=os.environ.get("WNE_LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )
    state_file = Path(os.environ.get("WNE_NFQ_STATE", "/run/wne/nfq_state.json"))
    states = load_states(state_file)
    if not states:
        log.info("no queues to bind; exiting")
        return

    queues: list[NetfilterQueue] = []
    threads: list[threading.Thread] = []

    for qnum, state in states.items():
        nfq = NetfilterQueue()

        def cb(pkt, s=state):
            if s.should_drop():
                pkt.drop()
            else:
                pkt.accept()

        nfq.bind(qnum, cb)
        queues.append(nfq)
        t = threading.Thread(target=nfq.run, daemon=True, name=f"nfq-{qnum}")
        t.start()
        threads.append(t)
        log.info("bound NFQUEUE %d (mode=%s)", qnum, state.mode)

    stop = threading.Event()

    def _term(signum, frame):
        log.info("received signal %d, stopping", signum)
        stop.set()

    signal.signal(signal.SIGTERM, _term)
    signal.signal(signal.SIGINT, _term)

    stop.wait()
    for nfq in queues:
        try:
            nfq.unbind()
        except Exception:
            pass


if __name__ == "__main__":
    main()
